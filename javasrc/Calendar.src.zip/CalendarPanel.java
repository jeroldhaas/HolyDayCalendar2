/*   1:    */ import java.awt.Component;
/*   2:    */ import java.awt.Dimension;
/*   3:    */ import java.awt.GridLayout;
/*   4:    */ import java.awt.Panel;
/*   5:    */ import java.awt.event.MouseEvent;
/*   6:    */ import java.awt.event.MouseListener;
/*   7:    */ 
/*   8:    */ public class CalendarPanel
/*   9:    */   extends Panel
/*  10:    */   implements MouseListener
/*  11:    */ {
/*  12:    */   CalendarBlock[][] block;
/*  13:    */   
/*  14:    */   public void mousePressed(MouseEvent evt) {}
/*  15:    */   
/*  16:    */   public void mouseReleased(MouseEvent evt) {}
/*  17:    */   
/*  18:    */   public void mouseEntered(MouseEvent evt) {}
/*  19:    */   
/*  20:    */   public void mouseClicked(MouseEvent evt) {}
/*  21:    */   
/*  22:    */   public void mouseExited(MouseEvent evt)
/*  23:    */   {
/*  24: 31 */     int x = evt.getX();
/*  25: 32 */     int y = evt.getY();
/*  26: 34 */     if ((x <= 1) || (x >= getSize().width - 1) || (y <= 1) || (y >= getSize().height - 1))
/*  27:    */     {
/*  28: 37 */       for (Object rWin = getParent(); !(rWin instanceof ResultWin); rWin = ((Component)rWin).getParent()) {}
/*  29: 38 */       ((ResultWin)rWin).getStatusBar().eraseMessage();
/*  30:    */     }
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void setMonth(Month month)
/*  34:    */   {
/*  35: 51 */     int i = 0;
/*  36: 52 */     int firstDOW = convDOW(month.getDay(0).getDOW());
/*  37:    */     
/*  38:    */ 
/*  39: 55 */     int chkyear = month.getYear().getYear();
/*  40: 57 */     if ((chkyear == 1582) && (month.getName() == "November")) {
/*  41: 58 */       firstDOW = 1;
/*  42:    */     }
/*  43: 59 */     if ((chkyear == 1582) && (month.getName() == "December")) {
/*  44: 60 */       firstDOW = 3;
/*  45:    */     }
/*  46: 63 */     int wk = 1;
/*  47:    */     do
/*  48:    */     {
/*  49: 66 */       int d = 0;
/*  50:    */       do
/*  51:    */       {
/*  52: 68 */         if (((wk == 1) && (firstDOW <= d)) || ((wk > 1) && (i < month.getNDays())))
/*  53:    */         {
/*  54: 70 */           ((DayBlock)this.block[wk][d]).setDay(month.getDay(i));
/*  55: 71 */           i++;
/*  56:    */         }
/*  57:    */         else
/*  58:    */         {
/*  59: 74 */           ((DayBlock)this.block[wk][d]).setDay(null);
/*  60:    */         }
/*  61: 76 */         d++;
/*  62: 76 */       } while (d < 7);
/*  63: 77 */       wk++;
/*  64: 77 */     } while (wk < 7);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public CalendarPanel()
/*  68:    */   {
/*  69: 82 */     this.block = new CalendarBlock[7][7];
/*  70: 83 */     setLayout(new GridLayout(7, 7, 1, 1));
/*  71: 84 */     this.block[0][0] = new TitleBlock("Sun");
/*  72: 85 */     this.block[0][1] = new TitleBlock("Mon");
/*  73: 86 */     this.block[0][2] = new TitleBlock("Tue");
/*  74: 87 */     this.block[0][3] = new TitleBlock("Wed");
/*  75: 88 */     this.block[0][4] = new TitleBlock("Thu");
/*  76: 89 */     this.block[0][5] = new TitleBlock("Fri");
/*  77: 90 */     this.block[0][6] = new TitleBlock("Sat");
/*  78: 91 */     int d = 0;
/*  79:    */     do
/*  80:    */     {
/*  81: 93 */       add(this.block[0][d]);
/*  82: 94 */       d++;
/*  83: 94 */     } while (d < 7);
/*  84: 95 */     int wk = 1;
/*  85:    */     do
/*  86:    */     {
/*  87: 98 */       d = 0;
/*  88:    */       do
/*  89:    */       {
/*  90:101 */         this.block[wk][d] = new DayBlock();
/*  91:102 */         add(this.block[wk][d]);
/*  92:103 */         d++;
/*  93:103 */       } while (d < 7);
/*  94:104 */       wk++;
/*  95:104 */     } while (wk < 7);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static int convDOW(int d)
/*  99:    */   {
/* 100:    */     
/* 101:113 */     if (d < 0) {
/* 102:114 */       d = 6;
/* 103:    */     }
/* 104:115 */     return d;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void repaint()
/* 108:    */   {
/* 109:120 */     int wk = 1;
/* 110:    */     do
/* 111:    */     {
/* 112:123 */       int d = 0;
/* 113:    */       do
/* 114:    */       {
/* 115:125 */         this.block[wk][d].repaint();
/* 116:126 */         d++;
/* 117:126 */       } while (d < 7);
/* 118:127 */       wk++;
/* 119:127 */     } while (wk < 7);
/* 120:    */   }
/* 121:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     CalendarPanel
 * JD-Core Version:    0.7.1
 */