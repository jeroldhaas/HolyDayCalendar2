/*   1:    */ import java.awt.Button;
/*   2:    */ import java.awt.Font;
/*   3:    */ import java.awt.GridBagLayout;
/*   4:    */ import java.awt.Label;
/*   5:    */ import java.awt.Panel;
/*   6:    */ import java.awt.TextField;
/*   7:    */ import java.awt.event.ActionEvent;
/*   8:    */ import java.awt.event.ActionListener;
/*   9:    */ 
/*  10:    */ public class Scroller
/*  11:    */   extends Panel
/*  12:    */   implements ActionListener
/*  13:    */ {
/*  14:    */   private Button bck;
/*  15:    */   private Button bck2;
/*  16:    */   private Button fwd;
/*  17:    */   private Button fwd2;
/*  18:    */   protected SelectWin applet;
/*  19:    */   protected TextField num;
/*  20:    */   
/*  21:    */   public Scroller(String type, SelectWin applet)
/*  22:    */   {
/*  23: 21 */     this.applet = applet;
/*  24:    */     
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30: 28 */     Label lb = new Label(" ");
/*  31:    */     
/*  32: 30 */     lb.setFont(new Font("Arial", 1, 10));
/*  33:    */     
/*  34: 32 */     GridBagLayout gb = new GridBagLayout();
/*  35:    */     
/*  36: 34 */     GBConstraints gbc = new GBConstraints();
/*  37:    */     
/*  38:    */ 
/*  39: 37 */     setLayout(gb);
/*  40:    */     
/*  41:    */ 
/*  42: 40 */     int cols = 2;
/*  43: 41 */     this.num = new TextField("1", cols);
/*  44: 42 */     this.num.setFont(new Font("Arial", 1, 12));
/*  45: 44 */     if (type.equals("Months"))
/*  46:    */     {
/*  47: 47 */       this.bck = new Button("< Months Backward");
/*  48: 48 */       this.bck.setFont(new Font("Arial", 1, 11));
/*  49:    */       
/*  50:    */ 
/*  51: 51 */       this.fwd = new Button("Months Forward >");
/*  52: 52 */       this.fwd.setFont(new Font("Arial", 1, 11));
/*  53:    */       
/*  54:    */ 
/*  55: 55 */       this.bck.addActionListener(this);
/*  56: 56 */       this.fwd.addActionListener(this);
/*  57:    */     }
/*  58:    */     else
/*  59:    */     {
/*  60: 60 */       this.bck2 = new Button("<< Years Backward");
/*  61: 61 */       this.bck2.setFont(new Font("Arial", 1, 11));
/*  62:    */       
/*  63: 63 */       this.fwd2 = new Button("Years Forward >>");
/*  64: 64 */       this.fwd2.setFont(new Font("Arial", 1, 11));
/*  65:    */       
/*  66: 66 */       this.bck2.addActionListener(this);
/*  67: 67 */       this.fwd2.addActionListener(this);
/*  68:    */     }
/*  69: 84 */     if (type.equals("Months"))
/*  70:    */     {
/*  71: 85 */       gb.setConstraints(this.bck, gbc.setConstraints(0, 0, 1, 1, 25, 100, 1, 10, 1, 0));
/*  72: 86 */       add(this.bck);
/*  73:    */       
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78: 92 */       gb.setConstraints(this.num, gbc.setConstraints(1, 0, 1, 1, 45, 100, 0, 13));
/*  79: 93 */       add(this.num);
/*  80:    */       
/*  81: 95 */       gb.setConstraints(lb, gbc.setConstraints(2, 0, 1, 1, 25, 100, 0, 17));
/*  82: 96 */       add(lb);
/*  83:    */       
/*  84: 98 */       gb.setConstraints(this.fwd, gbc.setConstraints(3, 0, 1, 1, 10, 100, 1, 10));
/*  85: 99 */       add(this.fwd);
/*  86:    */     }
/*  87:    */     else
/*  88:    */     {
/*  89:102 */       gb.setConstraints(this.bck2, gbc.setConstraints(0, 0, 1, 1, 25, 100, 1, 10, 1, 0));
/*  90:103 */       add(this.bck2);
/*  91:    */       
/*  92:105 */       gb.setConstraints(this.num, gbc.setConstraints(1, 0, 1, 1, 45, 100, 0, 13));
/*  93:106 */       add(this.num);
/*  94:    */       
/*  95:108 */       gb.setConstraints(lb, gbc.setConstraints(2, 0, 1, 1, 25, 100, 0, 17));
/*  96:109 */       add(lb);
/*  97:    */       
/*  98:111 */       gb.setConstraints(this.fwd2, gbc.setConstraints(3, 0, 1, 1, 10, 100, 1, 10));
/*  99:112 */       add(this.fwd2);
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void actionPerformed(ActionEvent evt)
/* 104:    */   {
/* 105:120 */     Object source = evt.getSource();
/* 106:122 */     if (source == this.bck)
/* 107:    */     {
/* 108:123 */       this.applet.decrSearchMonth(Integer.parseInt(this.num.getText()));
/* 109:124 */       this.applet.calculateDate();
/* 110:    */     }
/* 111:130 */     if (source == this.fwd)
/* 112:    */     {
/* 113:131 */       this.applet.incrSearchMonth(Integer.parseInt(this.num.getText()));
/* 114:132 */       this.applet.calculateDate();
/* 115:    */     }
/* 116:141 */     if (source == this.bck2)
/* 117:    */     {
/* 118:142 */       this.applet.decrSearchYear(Integer.parseInt(this.num.getText()));
/* 119:143 */       this.applet.calculateDate();
/* 120:    */     }
/* 121:146 */     if (source == this.fwd2)
/* 122:    */     {
/* 123:147 */       this.applet.incrSearchYear(Integer.parseInt(this.num.getText()));
/* 124:148 */       this.applet.calculateDate();
/* 125:    */     }
/* 126:    */   }
/* 127:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     Scroller
 * JD-Core Version:    0.7.1
 */