/*  1:   */ import java.awt.Canvas;
/*  2:   */ import java.awt.Color;
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.Font;
/*  5:   */ import java.awt.FontMetrics;
/*  6:   */ import java.awt.Graphics;
/*  7:   */ 
/*  8:   */ public class CalendarBlock
/*  9:   */   extends Canvas
/* 10:   */ {
/* 11:   */   public CalendarBlock()
/* 12:   */   {
/* 13: 9 */     this.bgcolor = BLANK;
/* 14:   */     
/* 15:   */ 
/* 16:12 */     this.f = new Font("Arial", 0, 11);
/* 17:13 */     this.fm = getFontMetrics(this.f);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void paint(Graphics g)
/* 21:   */   {
/* 22:18 */     g.setColor(Color.gray);
/* 23:   */     
/* 24:20 */     g.drawRect(1, 1, getSize().width - 2, getSize().height + 2);
/* 25:   */     
/* 26:22 */     g.setColor(Color.white);
/* 27:   */     
/* 28:24 */     g.drawRect(2, 2, getSize().width - 3, getSize().height - 3);
/* 29:   */     
/* 30:26 */     g.setColor(this.bgcolor);
/* 31:   */     
/* 32:28 */     g.fillRect(2, 2, getSize().width - 3, getSize().height - 3);
/* 33:   */   }
/* 34:   */   
/* 35:39 */   protected static final Color BLANK = Color.white;
/* 36:   */   protected Color bgcolor;
/* 37:   */   protected Font f;
/* 38:   */   protected FontMetrics fm;
/* 39:   */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     CalendarBlock
 * JD-Core Version:    0.7.1
 */