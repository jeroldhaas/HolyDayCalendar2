/*   1:    */ import java.awt.Button;
/*   2:    */ import java.awt.Color;
/*   3:    */ import java.awt.Font;
/*   4:    */ import java.awt.Frame;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.GridBagLayout;
/*   7:    */ import java.awt.Insets;
/*   8:    */ import java.awt.Label;
/*   9:    */ import java.awt.Menu;
/*  10:    */ import java.awt.MenuBar;
/*  11:    */ import java.awt.MenuItem;
/*  12:    */ import java.awt.event.ActionEvent;
/*  13:    */ import java.awt.event.ActionListener;
/*  14:    */ import java.awt.event.WindowEvent;
/*  15:    */ import java.awt.event.WindowListener;
/*  16:    */ 
/*  17:    */ public class ResultWin
/*  18:    */   extends Frame
/*  19:    */   implements WindowListener, ActionListener
/*  20:    */ {
/*  21:    */   private MenuItem mitem1;
/*  22:    */   private MenuItem mitem2;
/*  23:    */   private Button btcls;
/*  24:    */   private Button prtMonth;
/*  25:    */   private Button trmpDcl;
/*  26:    */   static boolean MonthOutADBC;
/*  27:    */   private boolean LunFlag;
/*  28:    */   TrumpDcl trumpDeclare;
/*  29:    */   private int TrmpSolarYear;
/*  30:    */   private String TrmpYearADBC;
/*  31:    */   protected static String prtLocFlag;
/*  32:    */   public SelectWin applet;
/*  33:    */   protected CalendarPanel grid;
/*  34:    */   protected Scroller mScroll;
/*  35:    */   protected Scroller yScroll;
/*  36:    */   protected ResWinTitle can;
/*  37:    */   protected StatusBar statusBar;
/*  38:    */   protected HelpWin hWin;
/*  39:    */   protected AboutWind abtWin;
/*  40:    */   
/*  41:    */   public void windowClosing(WindowEvent e)
/*  42:    */   {
/*  43: 69 */     dispose();
/*  44:    */     
/*  45:    */ 
/*  46:    */ 
/*  47: 73 */     this.applet.rWin = null;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void windowClosed(WindowEvent e) {}
/*  51:    */   
/*  52:    */   public void windowOpened(WindowEvent e) {}
/*  53:    */   
/*  54:    */   public void windowIconified(WindowEvent e) {}
/*  55:    */   
/*  56:    */   public void windowDeiconified(WindowEvent e) {}
/*  57:    */   
/*  58:    */   public void windowActivated(WindowEvent e) {}
/*  59:    */   
/*  60:    */   public void windowDeactivated(WindowEvent e) {}
/*  61:    */   
/*  62:    */   public void redraw(Month month)
/*  63:    */   {
/*  64:100 */     this.grid.setMonth(month);
/*  65:101 */     this.can.setMonth(month);
/*  66:    */     
/*  67:103 */     repaint();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public ResultWin(SelectWin applet)
/*  71:    */   {
/*  72:125 */     this.grid = new CalendarPanel();
/*  73:126 */     this.mScroll = new Scroller("Months", applet);
/*  74:127 */     this.yScroll = new Scroller("Years", applet);
/*  75:    */     
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:132 */     this.can = new ResWinTitle();
/*  80:    */     
/*  81:    */ 
/*  82:135 */     this.TrmpSolarYear = ResWinTitle.getCalSolarYear();
/*  83:136 */     this.TrmpYearADBC = ResWinTitle.getCalSolYearADBC();
/*  84:    */     
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:147 */     this.statusBar = new StatusBar();
/*  95:    */     
/*  96:    */ 
/*  97:150 */     this.LunFlag = true;
/*  98:151 */     this.LunFlag = SelectWin.getLunarFlag();
/*  99:153 */     if (this.LunFlag) {
/* 100:154 */       setTitle("Hebrew Format Calendar");
/* 101:    */     } else {
/* 102:156 */       setTitle("Roman Format Calendar");
/* 103:    */     }
/* 104:160 */     this.applet = applet;
/* 105:    */     
/* 106:162 */     MenuBar mbar = new MenuBar();
/* 107:    */     
/* 108:164 */     setMenuBar(mbar);
/* 109:    */     
/* 110:166 */     Menu aboutMenu = new Menu("Help");
/* 111:    */     
/* 112:168 */     this.mitem1 = new MenuItem("Help");
/* 113:169 */     this.mitem1.addActionListener(this);
/* 114:170 */     aboutMenu.add(this.mitem1);
/* 115:    */     
/* 116:172 */     this.mitem2 = new MenuItem("About this program");
/* 117:173 */     this.mitem2.addActionListener(this);
/* 118:174 */     aboutMenu.add(this.mitem2);
/* 119:    */     
/* 120:176 */     mbar.add(aboutMenu);
/* 121:    */     
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:189 */     GridBagLayout gb = new GridBagLayout();
/* 134:190 */     GBConstraints gbc = new GBConstraints();
/* 135:    */     
/* 136:192 */     addWindowListener(this);
/* 137:    */     
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:209 */     setLayout(gb);
/* 154:    */     
/* 155:    */ 
/* 156:212 */     gb.setConstraints(this.can, gbc.setConstraints(0, 1, 3, 1, 100, 13, 1, 10));
/* 157:213 */     add(this.can);
/* 158:    */     
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:220 */     gb.setConstraints(this.grid, gbc.setConstraints(0, 3, 3, 1, 100, 70, 1, 10));
/* 165:221 */     add(this.grid);
/* 166:    */     
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:226 */     gb.setConstraints(this.mScroll, gbc.setConstraints(0, 5, 3, 1, 85, 2));
/* 171:227 */     add(this.mScroll);
/* 172:    */     
/* 173:229 */     gb.setConstraints(this.yScroll, gbc.setConstraints(0, 6, 3, 1, 85, 2));
/* 174:230 */     add(this.yScroll);
/* 175:    */     
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:    */ 
/* 196:    */ 
/* 197:    */ 
/* 198:    */ 
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:277 */     Label lb = new Label(" ");
/* 222:278 */     gb.setConstraints(lb, gbc.setConstraints(0, 7, 1, 1, 40, 3));
/* 223:279 */     add(lb);
/* 224:    */     
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:284 */     this.trmpDcl = new Button("Trumpets Declaration");
/* 229:285 */     this.trmpDcl.addActionListener(this);
/* 230:286 */     this.trmpDcl.setFont(new Font("Arial", 1, 11));
/* 231:287 */     gb.setConstraints(this.trmpDcl, gbc.setConstraints(1, 7, 1, 1, 20, 3));
/* 232:288 */     add(this.trmpDcl);
/* 233:    */     
/* 234:290 */     lb = new Label(" ");
/* 235:291 */     gb.setConstraints(lb, gbc.setConstraints(2, 7, 1, 1, 40, 3));
/* 236:292 */     add(lb);
/* 237:    */     
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:301 */     gb.setConstraints(this.statusBar, gbc.setConstraints(0, 9, 3, 1, 100, 7));
/* 246:302 */     add(this.statusBar);
/* 247:    */     
/* 248:    */ 
/* 249:305 */     lb = new Label(" ");
/* 250:306 */     gb.setConstraints(lb, gbc.setConstraints(0, 10, 3, 1, 10, 1));
/* 251:307 */     add(lb);
/* 252:    */     
/* 253:    */ 
/* 254:    */ 
/* 255:311 */     lb = new Label(" ");
/* 256:312 */     gb.setConstraints(lb, gbc.setConstraints(0, 11, 1, 1, 40, 3));
/* 257:313 */     add(lb);
/* 258:    */     
/* 259:    */ 
/* 260:316 */     this.btcls = new Button("Close");
/* 261:317 */     this.btcls.addActionListener(this);
/* 262:318 */     this.btcls.setFont(new Font("Arial", 1, 11));
/* 263:319 */     gb.setConstraints(this.btcls, gbc.setConstraints(1, 11, 1, 1, 20, 3));
/* 264:320 */     add(this.btcls);
/* 265:    */     
/* 266:322 */     lb = new Label(" ");
/* 267:323 */     gb.setConstraints(lb, gbc.setConstraints(2, 11, 1, 1, 40, 3));
/* 268:324 */     add(lb);
/* 269:    */     
/* 270:    */ 
/* 271:327 */     lb = new Label(" ");
/* 272:328 */     gb.setConstraints(lb, gbc.setConstraints(0, 12, 3, 1, 1, 1));
/* 273:329 */     add(lb);
/* 274:    */     
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */ 
/* 280:336 */     setBackground(new Color(192, 192, 192));
/* 281:    */     
/* 282:338 */     setBounds(120, 35, 400, 500);
/* 283:    */     
/* 284:    */ 
/* 285:    */ 
/* 286:342 */     show();
/* 287:    */   }
/* 288:    */   
/* 289:    */   public void GenerateTDcl()
/* 290:    */   {
/* 291:409 */     int NewSearchYr = 1;
/* 292:410 */     boolean AdFlag = true;
/* 293:    */     
/* 294:    */ 
/* 295:413 */     NewSearchYr = SelectWin.getCalSolarYear();
/* 296:420 */     if (!this.LunFlag)
/* 297:    */     {
/* 298:422 */       if (NewSearchYr > 0)
/* 299:    */       {
/* 300:423 */         AdFlag = true;
/* 301:    */       }
/* 302:    */       else
/* 303:    */       {
/* 304:426 */         AdFlag = false;
/* 305:427 */         NewSearchYr = -NewSearchYr;
/* 306:    */       }
/* 307:    */     }
/* 308:    */     else
/* 309:    */     {
/* 310:436 */       NewSearchYr -= 3762;
/* 311:438 */       if (NewSearchYr == 0) {
/* 312:439 */         NewSearchYr = 1;
/* 313:    */       }
/* 314:441 */       if (NewSearchYr > 0)
/* 315:    */       {
/* 316:442 */         AdFlag = true;
/* 317:    */         
/* 318:444 */         NewSearchYr += 1;
/* 319:    */       }
/* 320:    */       else
/* 321:    */       {
/* 322:447 */         AdFlag = false;
/* 323:448 */         NewSearchYr = -NewSearchYr;
/* 324:    */       }
/* 325:    */     }
/* 326:452 */     String ConYear = String.valueOf(NewSearchYr);
/* 327:    */     
/* 328:    */ 
/* 329:    */ 
/* 330:456 */     HDWin CallHD = new HDWin(AdFlag, ConYear);
/* 331:    */     
/* 332:458 */     this.trumpDeclare = new TrumpDcl(this.TrmpSolarYear, this.TrmpYearADBC);
/* 333:    */   }
/* 334:    */   
/* 335:    */   public CalendarPanel getGrid()
/* 336:    */   {
/* 337:511 */     return this.grid;
/* 338:    */   }
/* 339:    */   
/* 340:    */   public Insets getInsets()
/* 341:    */   {
/* 342:527 */     return new Insets(40, 10, 25, 10);
/* 343:    */   }
/* 344:    */   
/* 345:    */   public StatusBar getStatusBar()
/* 346:    */   {
/* 347:532 */     return this.statusBar;
/* 348:    */   }
/* 349:    */   
/* 350:    */   public void actionPerformed(ActionEvent evt)
/* 351:    */   {
/* 352:547 */     Object source = evt.getSource();
/* 353:549 */     if (evt.getSource() == this.trmpDcl) {
/* 354:551 */       GenerateTDcl();
/* 355:    */     }
/* 356:555 */     if (evt.getSource() == this.btcls)
/* 357:    */     {
/* 358:557 */       dispose();
/* 359:    */       
/* 360:    */ 
/* 361:    */ 
/* 362:    */ 
/* 363:562 */       this.applet.rWin = null;
/* 364:    */     }
/* 365:569 */     if (source == this.mitem1) {
/* 366:572 */       this.hWin = new HelpWin("monthCal");
/* 367:    */     }
/* 368:580 */     if (source == this.mitem2) {
/* 369:581 */       this.abtWin = new AboutWind();
/* 370:    */     }
/* 371:    */   }
/* 372:    */   
/* 373:    */   public void paint(Graphics g)
/* 374:    */   {
/* 375:743 */     this.can.repaint();
/* 376:744 */     this.grid.repaint();
/* 377:745 */     this.statusBar.repaint();
/* 378:    */   }
/* 379:    */   
/* 380:    */   public Scroller getMScroll()
/* 381:    */   {
/* 382:764 */     return this.mScroll;
/* 383:    */   }
/* 384:    */   
/* 385:    */   public Scroller getYScroll()
/* 386:    */   {
/* 387:769 */     return this.yScroll;
/* 388:    */   }
/* 389:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     ResultWin
 * JD-Core Version:    0.7.1
 */