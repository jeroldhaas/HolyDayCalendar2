/*   1:    */ import java.awt.Color;
/*   2:    */ import java.awt.Component;
/*   3:    */ import java.awt.Dimension;
/*   4:    */ import java.awt.Font;
/*   5:    */ import java.awt.FontMetrics;
/*   6:    */ import java.awt.Frame;
/*   7:    */ import java.awt.Graphics;
/*   8:    */ import java.awt.event.MouseEvent;
/*   9:    */ import java.awt.event.MouseListener;
/*  10:    */ 
/*  11:    */ public class DayBlock
/*  12:    */   extends CalendarBlock
/*  13:    */   implements MouseListener
/*  14:    */ {
/*  15:    */   protected Day day;
/*  16:    */   protected Day realDay;
/*  17:    */   
/*  18:    */   public void mousePressed(MouseEvent evt) {}
/*  19:    */   
/*  20:    */   public void mouseReleased(MouseEvent evt) {}
/*  21:    */   
/*  22:    */   public void mouseExited(MouseEvent evt) {}
/*  23:    */   
/*  24:    */   public void mouseClicked(MouseEvent evt) {}
/*  25:    */   
/*  26:    */   public void mouseEntered(MouseEvent evt)
/*  27:    */   {
/*  28: 45 */     for (Object rWin = getParent(); !(rWin instanceof Frame); rWin = ((Component)rWin).getParent()) {}
/*  29: 47 */     if (this.day != null) {
/*  30: 48 */       ((ResultWin)rWin).getStatusBar().showMessage(this.day.getHag());
/*  31:    */     }
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setDay(Day dy)
/*  35:    */   {
/*  36: 55 */     if (dy != null)
/*  37:    */     {
/*  38: 57 */       this.realDay = dy;
/*  39: 58 */       if ((dy.getMonth().getYear() instanceof LunarYear)) {
/*  40: 59 */         this.day = dy;
/*  41:    */       } else {
/*  42: 61 */         this.day = dy.getOther();
/*  43:    */       }
/*  44: 62 */       this.bgcolor = this.day.getBgcolor();
/*  45:    */       
/*  46:    */ 
/*  47: 65 */       addMouseListener(this);
/*  48:    */     }
/*  49:    */     else
/*  50:    */     {
/*  51: 71 */       this.day = null;
/*  52: 72 */       this.realDay = null;
/*  53: 73 */       this.bgcolor = CalendarBlock.BLANK;
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Day getDay()
/*  58:    */   {
/*  59: 79 */     return this.day;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void paint(Graphics g)
/*  63:    */   {
/*  64: 84 */     super.paint(g);
/*  65: 85 */     if (this.day != null)
/*  66:    */     {
/*  67: 88 */       this.f = new Font("Arial", 1, 12);
/*  68: 89 */       this.fm = getFontMetrics(this.f);
/*  69:    */       
/*  70:    */ 
/*  71:    */ 
/*  72: 93 */       g.setFont(this.f);
/*  73:    */       
/*  74: 95 */       String date = Integer.toString(this.realDay.getDate() + 1);
/*  75:    */       
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:100 */       int ckdate = this.realDay.getDate() + 1;
/*  80:101 */       int ckothdate = this.realDay.getOther().getDate() + 1;
/*  81:102 */       int ckyear = this.realDay.getMonth().getYear().getYear();
/*  82:103 */       String ckmonth = this.realDay.getMonth().getName();
/*  83:104 */       boolean frstyrsolar = false;
/*  84:107 */       if (((this.realDay.getMonth().getYear() instanceof SolarYear)) && (ckyear == 1582))
/*  85:    */       {
/*  86:109 */         frstyrsolar = true;
/*  87:110 */         int lunday = this.realDay.getOther().getDate() + 1;
/*  88:112 */         if ((ckmonth == "October") && (ckdate > 4) && (ckdate < 22)) {
/*  89:114 */           date = Integer.toString(ckdate + 10);
/*  90:    */         }
/*  91:    */       }
/*  92:121 */       if ((frstyrsolar != true) || (ckyear != 1582) || (ckmonth != "October") || (ckdate <= 21))
/*  93:    */       {
/*  94:123 */         g.setColor(Color.blue);
/*  95:    */         
/*  96:    */ 
/*  97:    */ 
/*  98:127 */         g.drawString(date, (int)(0.5D * (0.5D * getSize().width - this.fm.stringWidth(date)) + 0.5D), (int)(0.5D * (0.5D * getSize().height + this.fm.getHeight()) + 0.5D));
/*  99:    */         
/* 100:129 */         String date2 = Integer.toString(this.realDay.getOther().getDate() + 1);
/* 101:131 */         if ((ckyear == 1582) && ((frstyrsolar = 1) != 0))
/* 102:    */         {
/* 103:132 */           if (((ckmonth == "November") || (ckmonth == "December")) && (ckdate > 0) && (ckdate < 16)) {
/* 104:133 */             date2 = Integer.toString(ckothdate - 10);
/* 105:    */           }
/* 106:135 */           if (((ckmonth == "November") || (ckmonth == "December")) && (ckdate > 15) && (ckdate < 26)) {
/* 107:136 */             date2 = Integer.toString(ckothdate + 20);
/* 108:    */           }
/* 109:138 */           if (((ckmonth == "November") || (ckmonth == "December")) && (ckdate > 25) && (ckdate < 32)) {
/* 110:139 */             date2 = Integer.toString(ckothdate - 10);
/* 111:    */           }
/* 112:    */         }
/* 113:148 */         if (((this.realDay.getMonth().getYear() instanceof LunarYear)) && (ckyear == 5343))
/* 114:    */         {
/* 115:150 */           if ((ckmonth == "Tishri") && (ckdate > 0) && (ckdate < 5)) {
/* 116:152 */             date2 = Integer.toString(ckothdate - 10);
/* 117:    */           }
/* 118:155 */           if ((ckmonth == "Tishri") && (ckdate > 4) && (ckdate < 15)) {
/* 119:157 */             date2 = Integer.toString(ckothdate + 20);
/* 120:    */           }
/* 121:159 */           if ((ckmonth == "Tishri") && (ckdate > 14) && (ckdate < 19)) {
/* 122:161 */             date2 = Integer.toString(ckothdate - 10);
/* 123:    */           }
/* 124:    */         }
/* 125:166 */         g.setColor(Color.red);
/* 126:    */         
/* 127:168 */         g.drawString(date2, (int)(0.5D * (0.5D * getSize().width - this.fm.stringWidth(date)) + 0.5D * getSize().width + 0.5D), (int)(0.5D * (0.5D * getSize().height + this.fm.getHeight()) + 0.5D));
/* 128:    */       }
/* 129:    */     }
/* 130:    */   }
/* 131:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     DayBlock
 * JD-Core Version:    0.7.1
 */