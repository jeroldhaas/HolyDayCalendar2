/*  1:   */ import java.awt.Canvas;
/*  2:   */ import java.awt.Color;
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.Font;
/*  5:   */ import java.awt.FontMetrics;
/*  6:   */ import java.awt.Graphics;
/*  7:   */ 
/*  8:   */ public class StatusBar
/*  9:   */   extends Canvas
/* 10:   */ {
/* 11:   */   Font f;
/* 12:   */   FontMetrics fm;
/* 13:   */   String message;
/* 14:   */   
/* 15:   */   public void showMessage(String s)
/* 16:   */   {
/* 17:16 */     this.message = s;
/* 18:   */     
/* 19:18 */     repaint();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public StatusBar()
/* 23:   */   {
/* 24:28 */     this.f = new Font("Arial", 1, 12);
/* 25:29 */     this.fm = getFontMetrics(this.f);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void eraseMessage()
/* 29:   */   {
/* 30:35 */     this.message = null;
/* 31:36 */     repaint();
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void paint(Graphics g)
/* 35:   */   {
/* 36:47 */     g.setColor(Color.black);
/* 37:48 */     g.drawRect(1, 1, getSize().width - 2, getSize().height - 2);
/* 38:49 */     g.setColor(Color.white);
/* 39:50 */     g.drawRect(2, 2, getSize().width - 3, getSize().height - 3);
/* 40:   */     
/* 41:   */ 
/* 42:   */ 
/* 43:54 */     g.setColor(Color.white);
/* 44:55 */     g.fillRect(2, 2, getSize().width - 3, getSize().height - 3);
/* 45:57 */     if (this.message != null)
/* 46:   */     {
/* 47:59 */       g.setColor(Color.black);
/* 48:   */       
/* 49:61 */       this.f = new Font("Arial", 1, 12);
/* 50:62 */       this.fm = getFontMetrics(this.f);
/* 51:63 */       g.setFont(this.f);
/* 52:   */       
/* 53:65 */       g.drawString(this.message, 4, (int)((getSize().height + this.fm.getHeight()) / 2 + 0.5D));
/* 54:   */     }
/* 55:   */   }
/* 56:   */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     StatusBar
 * JD-Core Version:    0.7.1
 */