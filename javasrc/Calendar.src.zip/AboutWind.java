/*   1:    */ import java.awt.BorderLayout;
/*   2:    */ import java.awt.Color;
/*   3:    */ import java.awt.Dimension;
/*   4:    */ import java.awt.Font;
/*   5:    */ import java.awt.GridBagConstraints;
/*   6:    */ import java.awt.GridBagLayout;
/*   7:    */ import java.awt.Insets;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.awt.event.ActionListener;
/*  10:    */ import java.awt.event.WindowEvent;
/*  11:    */ import java.awt.event.WindowListener;
/*  12:    */ import javax.swing.BoxLayout;
/*  13:    */ import javax.swing.JButton;
/*  14:    */ import javax.swing.JFrame;
/*  15:    */ import javax.swing.JLabel;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import javax.swing.JScrollPane;
/*  18:    */ import javax.swing.JTextArea;
/*  19:    */ 
/*  20:    */ public class AboutWind
/*  21:    */   extends JFrame
/*  22:    */   implements WindowListener, ActionListener
/*  23:    */ {
/*  24:    */   private JButton ClsingButton;
/*  25:    */   private JButton PButton;
/*  26:    */   JPanel ContentsPanel;
/*  27:    */   JPanel sArea;
/*  28:    */   JPanel buttBottom;
/*  29:    */   JTextArea txtArea;
/*  30:    */   JFrame aboutFrame;
/*  31:    */   JLabel ATitle;
/*  32:    */   JLabel AText;
/*  33:    */   GridBagLayout gridbag;
/*  34:    */   GridBagConstraints c;
/*  35:    */   
/*  36:    */   public void actionPerformed(ActionEvent evt)
/*  37:    */   {
/*  38: 27 */     Object source = evt.getSource();
/*  39: 28 */     if (source == this.ClsingButton) {
/*  40: 31 */       this.aboutFrame.hide();
/*  41:    */     }
/*  42: 34 */     if (source == this.PButton)
/*  43:    */     {
/*  44: 36 */       String prtLocFlag = "AboutWind";
/*  45: 37 */       PrintUtilities.printComponent(this.aboutFrame, prtLocFlag);
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void windowClosing(WindowEvent e)
/*  50:    */   {
/*  51: 46 */     setVisible(false);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void windowClosed(WindowEvent e) {}
/*  55:    */   
/*  56:    */   public void windowOpened(WindowEvent e) {}
/*  57:    */   
/*  58:    */   public void windowIconified(WindowEvent e) {}
/*  59:    */   
/*  60:    */   public void windowDeiconified(WindowEvent e) {}
/*  61:    */   
/*  62:    */   public void windowActivated(WindowEvent e) {}
/*  63:    */   
/*  64:    */   public void windowDeactivated(WindowEvent e) {}
/*  65:    */   
/*  66:    */   public AboutWind()
/*  67:    */   {
/*  68: 71 */     super("About Holy Day Calendar");
/*  69:    */     
/*  70: 73 */     this.aboutFrame = new JFrame("About Holy Day Calendar");
/*  71: 74 */     this.aboutFrame.addWindowListener(this);
/*  72:    */     
/*  73: 76 */     this.aboutFrame.setSize(400, 300);
/*  74:    */     
/*  75: 78 */     this.aboutFrame.setDefaultCloseOperation(1);
/*  76:    */     
/*  77: 80 */     this.ContentsPanel = new JPanel();
/*  78: 81 */     this.ContentsPanel.setOpaque(true);
/*  79: 82 */     this.ContentsPanel.setBackground(Color.white);
/*  80: 83 */     this.ContentsPanel.setSize(400, 300);
/*  81:    */     
/*  82:    */ 
/*  83: 86 */     this.ContentsPanel.setLayout(new BorderLayout(5, 7));
/*  84:    */     
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88: 91 */     this.aboutFrame.setContentPane(this.ContentsPanel);
/*  89:    */     
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93: 96 */     this.ATitle = new JLabel("About Holy Day Calendar", 0);
/*  94:    */     
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:101 */     this.ATitle.setFont(new Font("Arial", 1, 14));
/*  99:    */     
/* 100:103 */     this.ATitle.setPreferredSize(new Dimension(400, 25));
/* 101:104 */     this.ATitle.setMinimumSize(new Dimension(400, 25));
/* 102:    */     
/* 103:    */ 
/* 104:107 */     this.ContentsPanel.add(this.ATitle, "North");
/* 105:    */     
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:112 */     this.sArea = new JPanel();
/* 110:113 */     this.sArea.setOpaque(true);
/* 111:114 */     this.sArea.setBackground(Color.white);
/* 112:    */     
/* 113:    */ 
/* 114:117 */     this.sArea.setLayout(new BoxLayout(this.sArea, 1));
/* 115:    */     
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:122 */     this.buttBottom = new JPanel();
/* 120:123 */     this.buttBottom.setOpaque(true);
/* 121:124 */     this.buttBottom.setBackground(Color.white);
/* 122:    */     
/* 123:    */ 
/* 124:    */ 
/* 125:128 */     this.gridbag = new GridBagLayout();
/* 126:129 */     this.c = new GridBagConstraints();
/* 127:    */     
/* 128:131 */     this.buttBottom.setLayout(this.gridbag);
/* 129:    */     
/* 130:    */ 
/* 131:134 */     this.c.gridx = 1;
/* 132:135 */     this.c.gridy = 0;
/* 133:136 */     this.c.gridwidth = 1;
/* 134:    */     
/* 135:138 */     this.c.anchor = 10;
/* 136:139 */     this.c.gridheight = 1;
/* 137:    */     
/* 138:141 */     this.c.weightx = 1.0D;
/* 139:142 */     this.c.weighty = 1.0D;
/* 140:    */     
/* 141:144 */     this.c.insets = new Insets(3, 0, 3, 0);
/* 142:    */     
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:155 */     this.txtArea = new JTextArea("For information on the history and structure of the Hebrew Calendar write:\n\nChristian Biblical Church of God\nP.O. Box 1442\nHollister, California\n95024-1442\nE-mail: FredCoulter@mindspring.com\n\n**In order to receive a reply when writing to Mr. Coulter, please include your home mailing address.**\n\nWebmaster Email: rlcary@mindspring.com\nPhone: 1-831-637-1875\nFax: 1-831-637-9616\nhttp://www.cbcg.org/\n\nOriginal JAVA Code created by Rafi Stern (1997-98).\nUpdates, additions and corrections to original code made by Alan Ruth (2003).  New JAVA code created by Alan Ruth (2003).\n\n(c) Christian Biblical Church of God.\n\n\n");
/* 153:    */     
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:168 */     this.txtArea.setEditable(false);
/* 166:169 */     this.txtArea.setLineWrap(true);
/* 167:170 */     this.txtArea.setWrapStyleWord(true);
/* 168:171 */     this.txtArea.setFont(new Font("Arial", 0, 12));
/* 169:172 */     this.txtArea.setAlignmentX(0.5F);
/* 170:173 */     this.txtArea.setMargin(new Insets(0, 3, 0, 3));
/* 171:    */     
/* 172:    */ 
/* 173:176 */     JScrollPane sPane = new JScrollPane(this.txtArea);
/* 174:177 */     sPane.setSize(new Dimension(400, 300));
/* 175:    */     
/* 176:    */ 
/* 177:180 */     sPane.setVerticalScrollBarPolicy(20);
/* 178:181 */     sPane.setHorizontalScrollBarPolicy(30);
/* 179:    */     
/* 180:    */ 
/* 181:    */ 
/* 182:185 */     this.sArea.setAlignmentX(0.5F);
/* 183:186 */     this.sArea.add(sPane);
/* 184:    */     
/* 185:188 */     this.ContentsPanel.add(this.sArea, "Center");
/* 186:    */     
/* 187:    */ 
/* 188:191 */     this.PButton = new JButton("Print");
/* 189:192 */     this.PButton.addActionListener(this);
/* 190:    */     
/* 191:194 */     this.PButton.setPreferredSize(new Dimension(100, 20));
/* 192:195 */     this.PButton.setMinimumSize(new Dimension(100, 20));
/* 193:196 */     this.PButton.setFont(new Font("Arial", 1, 12));
/* 194:197 */     this.PButton.setMargin(new Insets(1, 0, 1, 0));
/* 195:    */     
/* 196:    */ 
/* 197:200 */     this.buttBottom.add(this.PButton, this.c);
/* 198:    */     
/* 199:    */ 
/* 200:203 */     this.c.gridx = 1;
/* 201:204 */     this.c.gridy = 1;
/* 202:    */     
/* 203:206 */     this.ClsingButton = new JButton("Close");
/* 204:207 */     this.ClsingButton.addActionListener(this);
/* 205:    */     
/* 206:209 */     this.ClsingButton.setPreferredSize(new Dimension(150, 20));
/* 207:210 */     this.ClsingButton.setMinimumSize(new Dimension(150, 20));
/* 208:211 */     this.ClsingButton.setFont(new Font("Arial", 1, 12));
/* 209:212 */     this.ClsingButton.setMargin(new Insets(1, 0, 1, 0));
/* 210:    */     
/* 211:    */ 
/* 212:215 */     this.buttBottom.add(this.ClsingButton, this.c);
/* 213:    */     
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:226 */     this.ContentsPanel.add(this.buttBottom, "South");
/* 224:227 */     addWindowListener(this);
/* 225:    */     
/* 226:229 */     this.aboutFrame.pack();
/* 227:230 */     this.aboutFrame.setVisible(true);
/* 228:    */   }
/* 229:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     AboutWind
 * JD-Core Version:    0.7.1
 */