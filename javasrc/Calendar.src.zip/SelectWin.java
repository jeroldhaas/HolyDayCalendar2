/*    1:     */ import java.awt.Color;
/*    2:     */ import java.awt.Dimension;
/*    3:     */ import java.awt.Font;
/*    4:     */ import java.awt.GridBagConstraints;
/*    5:     */ import java.awt.GridBagLayout;
/*    6:     */ import java.awt.Insets;
/*    7:     */ import java.awt.PrintJob;
/*    8:     */ import java.awt.event.ActionEvent;
/*    9:     */ import java.awt.event.ActionListener;
/*   10:     */ import java.awt.event.ItemEvent;
/*   11:     */ import java.awt.event.ItemListener;
/*   12:     */ import java.awt.event.WindowEvent;
/*   13:     */ import java.awt.event.WindowListener;
/*   14:     */ import javax.swing.BoxLayout;
/*   15:     */ import javax.swing.ButtonGroup;
/*   16:     */ import javax.swing.JButton;
/*   17:     */ import javax.swing.JCheckBox;
/*   18:     */ import javax.swing.JComboBox;
/*   19:     */ import javax.swing.JFrame;
/*   20:     */ import javax.swing.JLabel;
/*   21:     */ import javax.swing.JMenu;
/*   22:     */ import javax.swing.JMenuBar;
/*   23:     */ import javax.swing.JMenuItem;
/*   24:     */ import javax.swing.JPanel;
/*   25:     */ import javax.swing.JTextField;
/*   26:     */ import javax.swing.border.EmptyBorder;
/*   27:     */ 
/*   28:     */ public class SelectWin
/*   29:     */   extends JFrame
/*   30:     */   implements WindowListener, ActionListener, ItemListener
/*   31:     */ {
/*   32:     */   private JMenuItem m1;
/*   33:     */   private JMenuItem m2;
/*   34:     */   private JButton b1;
/*   35:     */   private JButton b2;
/*   36:     */   JMenuBar mbar;
/*   37:     */   JMenu aboutMenu;
/*   38:     */   ButtonGroup cbg;
/*   39:     */   JCheckBox chkbxAD;
/*   40:     */   JCheckBox chkbxBC;
/*   41:     */   public static int CalSolarYear;
/*   42:  49 */   boolean ADselected = true;
/*   43:     */   JLabel helplab;
/*   44:     */   JLabel lb;
/*   45:     */   JFrame inpframe;
/*   46:     */   JPanel inpPanel;
/*   47:     */   GridBagConstraints gc;
/*   48:     */   GridBagLayout gb;
/*   49:     */   JComboBox monthMenu;
/*   50:     */   protected JTextField yearField;
/*   51:     */   protected static JPanel TrblShoot;
/*   52:     */   JFrame TrblFrame;
/*   53:     */   protected static JLabel TrblText;
/*   54:     */   public ResultWin rWin;
/*   55:     */   protected static int sYr;
/*   56:     */   protected static boolean lFlag;
/*   57:     */   public static ResultWin StatrWin;
/*   58:     */   public static PrintJob pjob;
/*   59:     */   protected HelpWin hWin;
/*   60:     */   protected int searchMonth;
/*   61:     */   protected int searchYear;
/*   62:     */   protected int YearInput;
/*   63:     */   protected boolean ADBCflag;
/*   64:     */   protected AboutWind abWin;
/*   65:     */   protected boolean lunarFlag;
/*   66:     */   protected boolean eretzFlag;
/*   67:     */   private boolean firstFlag;
/*   68:     */   private boolean leapFlag;
/*   69:     */   private boolean backFlag;
/*   70:     */   private boolean lastLeapFlag;
/*   71:     */   
/*   72:     */   public void tshoot()
/*   73:     */   {
/*   74:  76 */     this.TrblFrame = new JFrame("TROUBLESHOOTING PANEL");
/*   75:     */     
/*   76:     */ 
/*   77:  79 */     this.TrblFrame.setSize(600, 600);
/*   78:     */     
/*   79:  81 */     this.TrblFrame.setDefaultCloseOperation(1);
/*   80:  82 */     TrblShoot = new JPanel();
/*   81:     */     
/*   82:     */ 
/*   83:  85 */     TrblShoot.setLayout(new BoxLayout(TrblShoot, 1));
/*   84:  86 */     TrblShoot.setSize(600, 600);
/*   85:     */     
/*   86:     */ 
/*   87:  89 */     this.TrblFrame.setContentPane(TrblShoot);
/*   88:  90 */     TrblShoot.setOpaque(true);
/*   89:     */     
/*   90:     */ 
/*   91:     */ 
/*   92:  94 */     TrblText = new JLabel("TROUBLESHOOTING PANEL FOR SELECTWIN", 0);
/*   93:  95 */     TrblText.setAlignmentX(0.5F);
/*   94:  96 */     TrblShoot.add(TrblText);
/*   95:     */     
/*   96:  98 */     TrblText.setAlignmentX(0.0F);
/*   97:     */   }
/*   98:     */   
/*   99:     */   public void windowClosing(WindowEvent e)
/*  100:     */   {
/*  101: 126 */     setVisible(false);
/*  102:     */   }
/*  103:     */   
/*  104:     */   public void windowClosed(WindowEvent e) {}
/*  105:     */   
/*  106:     */   public void windowOpened(WindowEvent e) {}
/*  107:     */   
/*  108:     */   public void windowIconified(WindowEvent e) {}
/*  109:     */   
/*  110:     */   public void windowDeiconified(WindowEvent e) {}
/*  111:     */   
/*  112:     */   public void windowActivated(WindowEvent e) {}
/*  113:     */   
/*  114:     */   public void windowDeactivated(WindowEvent e) {}
/*  115:     */   
/*  116:     */   public void itemStateChanged(ItemEvent e) {}
/*  117:     */   
/*  118:     */   public void setSearchMonth()
/*  119:     */   {
/*  120: 154 */     this.searchMonth = 0;
/*  121:     */     
/*  122: 156 */     int nIndex = this.monthMenu.getSelectedIndex();
/*  123: 158 */     if (nIndex >= 0) {
/*  124: 159 */       if (this.lunarFlag)
/*  125:     */       {
/*  126: 161 */         if (nIndex < 13) {
/*  127: 162 */           this.searchMonth = nIndex;
/*  128:     */         }
/*  129:     */       }
/*  130: 164 */       else if (nIndex < 12) {
/*  131: 165 */         this.searchMonth = nIndex;
/*  132:     */       }
/*  133:     */     }
/*  134:     */   }
/*  135:     */   
/*  136:     */   public int getInpYear()
/*  137:     */   {
/*  138:     */     try
/*  139:     */     {
/*  140: 196 */       return new Integer(this.yearField.getText()).intValue();
/*  141:     */     }
/*  142:     */     catch (NumberFormatException e) {}
/*  143: 201 */     return 1;
/*  144:     */   }
/*  145:     */   
/*  146:     */   public int getMonth()
/*  147:     */   {
/*  148: 210 */     return this.monthMenu.getSelectedIndex();
/*  149:     */   }
/*  150:     */   
/*  151:     */   public String getMonthName()
/*  152:     */   {
/*  153: 217 */     return (String)this.monthMenu.getSelectedItem();
/*  154:     */   }
/*  155:     */   
/*  156:     */   public static int getCalSolarYear()
/*  157:     */   {
/*  158: 223 */     return CalSolarYear;
/*  159:     */   }
/*  160:     */   
/*  161:     */   public void SearchingDate()
/*  162:     */   {
/*  163: 249 */     if (this.lunarFlag)
/*  164:     */     {
/*  165: 253 */       String[] monthnames = { "Tishri", "Heshvan", "Kislev", "Tebet", "Shebat", "Adar I", "Adar II", "Nisan", "Iyar", "Sivan", "Tammuz", "Ab", "Elul" };
/*  166: 254 */       this.monthMenu = new JComboBox(monthnames);
/*  167:     */     }
/*  168:     */     else
/*  169:     */     {
/*  170: 257 */       String[] monthnames = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
/*  171: 258 */       this.monthMenu = new JComboBox(monthnames);
/*  172:     */     }
/*  173: 263 */     this.monthMenu.setSelectedIndex(0);
/*  174:     */     
/*  175: 265 */     this.monthMenu.addActionListener(this);
/*  176: 266 */     this.monthMenu.addItemListener(this);
/*  177: 267 */     this.monthMenu.setFont(new Font("Arial", 1, 12));
/*  178: 268 */     this.monthMenu.setBackground(Color.white);
/*  179:     */     
/*  180: 270 */     this.gc.gridx = 0;
/*  181: 271 */     this.gc.gridy = 2;
/*  182: 272 */     this.gc.anchor = 17;
/*  183:     */     
/*  184: 274 */     this.lb = new JLabel("Month:");
/*  185:     */     
/*  186: 276 */     this.lb.setFont(new Font("Arial", 1, 12));
/*  187: 277 */     this.lb.setForeground(Color.BLACK);
/*  188: 278 */     EmptyBorder brder = new EmptyBorder(new Insets(10, 5, 0, 0));
/*  189: 279 */     this.lb.setBorder(brder);
/*  190:     */     
/*  191: 281 */     this.inpPanel.add(this.lb, this.gc);
/*  192:     */     
/*  193:     */ 
/*  194:     */ 
/*  195:     */ 
/*  196: 286 */     this.gc.insets = new Insets(10, 0, 0, 0);
/*  197: 287 */     this.gc.gridx = 1;
/*  198:     */     
/*  199:     */ 
/*  200:     */ 
/*  201: 291 */     this.gc.gridy = 2;
/*  202:     */     
/*  203:     */ 
/*  204: 294 */     this.inpPanel.add(this.monthMenu, this.gc);
/*  205:     */     
/*  206:     */ 
/*  207:     */ 
/*  208:     */ 
/*  209:     */ 
/*  210:     */ 
/*  211:     */ 
/*  212:     */ 
/*  213:     */ 
/*  214:     */ 
/*  215:     */ 
/*  216:     */ 
/*  217:     */ 
/*  218:     */ 
/*  219:     */ 
/*  220:     */ 
/*  221: 311 */     this.lb = new JLabel("Year:", 2);
/*  222:     */     
/*  223: 313 */     this.lb.setFont(new Font("Arial", 1, 12));
/*  224: 314 */     this.lb.setForeground(Color.BLACK);
/*  225:     */     
/*  226: 316 */     brder = new EmptyBorder(new Insets(0, 5, 0, 0));
/*  227: 317 */     this.lb.setBorder(brder);
/*  228: 318 */     this.gc.gridwidth = 1;
/*  229: 319 */     this.gc.gridx = 0;
/*  230: 320 */     this.gc.gridy = 3;
/*  231:     */     
/*  232: 322 */     this.inpPanel.add(this.lb, this.gc);
/*  233:     */     
/*  234:     */ 
/*  235:     */ 
/*  236:     */ 
/*  237: 327 */     this.yearField = new JTextField();
/*  238: 328 */     Dimension shtfield = new Dimension(50, 20);
/*  239: 329 */     this.yearField.setPreferredSize(shtfield);
/*  240:     */     
/*  241: 331 */     this.gc.gridx = 1;
/*  242: 332 */     this.gc.gridy = 3;
/*  243: 333 */     this.gc.weightx = 1.0D;
/*  244:     */     
/*  245:     */ 
/*  246:     */ 
/*  247: 337 */     this.inpPanel.add(this.yearField, this.gc);
/*  248: 338 */     this.yearField.addActionListener(this);
/*  249:     */     
/*  250:     */ 
/*  251:     */ 
/*  252:     */ 
/*  253:     */ 
/*  254: 344 */     this.cbg = new ButtonGroup();
/*  255:     */     
/*  256:     */ 
/*  257:     */ 
/*  258: 348 */     this.chkbxBC = new JCheckBox("BC", false);
/*  259:     */     
/*  260: 350 */     this.chkbxBC.setBackground(Color.white);
/*  261:     */     
/*  262: 352 */     this.gc.gridx = 2;
/*  263: 353 */     this.gc.gridy = 3;
/*  264: 354 */     this.inpPanel.add(this.chkbxBC, this.gc);
/*  265:     */     
/*  266: 356 */     this.cbg.add(this.chkbxBC);
/*  267:     */     
/*  268:     */ 
/*  269: 359 */     this.gc.gridx = -1;
/*  270: 360 */     this.gc.gridy = 3;
/*  271: 361 */     this.gc.gridwidth = 1;
/*  272: 362 */     this.gc.gridheight = 1;
/*  273:     */     
/*  274: 364 */     this.chkbxAD = new JCheckBox("AD", true);
/*  275: 365 */     this.chkbxAD.setBackground(Color.white);
/*  276:     */     
/*  277: 367 */     this.inpPanel.add(this.chkbxAD, this.gc);
/*  278: 368 */     this.cbg.add(this.chkbxAD);
/*  279:     */     
/*  280:     */ 
/*  281:     */ 
/*  282:     */ 
/*  283:     */ 
/*  284:     */ 
/*  285:     */ 
/*  286:     */ 
/*  287:     */ 
/*  288: 378 */     this.chkbxAD.addItemListener(this);
/*  289: 379 */     this.chkbxBC.addItemListener(this);
/*  290:     */   }
/*  291:     */   
/*  292:     */   public void getYearCal()
/*  293:     */   {
/*  294: 394 */     SolarYear HDSolYear = new SolarYear(this.YearInput);
/*  295:     */     LunarYear HDLunYear;
/*  296:     */     LunarYear HDLunYear;
/*  297: 396 */     if (this.ADBCflag) {
/*  298: 398 */       HDLunYear = new LunarYear(this.YearInput + 3760, false);
/*  299:     */     } else {
/*  300: 402 */       HDLunYear = new LunarYear(3761 - this.YearInput, false);
/*  301:     */     }
/*  302:     */   }
/*  303:     */   
/*  304:     */   public SelectWin(boolean lunarFlag)
/*  305:     */   {
/*  306: 438 */     super("Select Date");
/*  307:     */     
/*  308:     */ 
/*  309:     */ 
/*  310:     */ 
/*  311:     */ 
/*  312:     */ 
/*  313:     */ 
/*  314:     */ 
/*  315:     */ 
/*  316:     */ 
/*  317:     */ 
/*  318:     */ 
/*  319:     */ 
/*  320:     */ 
/*  321:     */ 
/*  322:     */ 
/*  323:     */ 
/*  324:     */ 
/*  325:     */ 
/*  326:     */ 
/*  327:     */ 
/*  328:     */ 
/*  329:     */ 
/*  330:     */ 
/*  331: 463 */     this.inpframe = new JFrame("Select Date");
/*  332:     */     
/*  333: 465 */     setDefaultCloseOperation(2);
/*  334:     */     
/*  335:     */ 
/*  336: 468 */     this.inpPanel = new JPanel();
/*  337:     */     
/*  338: 470 */     this.inpframe.setContentPane(this.inpPanel);
/*  339:     */     
/*  340:     */ 
/*  341: 473 */     this.inpPanel.setOpaque(true);
/*  342:     */     
/*  343:     */ 
/*  344: 476 */     this.inpPanel.setBackground(Color.white);
/*  345:     */     
/*  346:     */ 
/*  347:     */ 
/*  348: 480 */     this.gb = new GridBagLayout();
/*  349: 481 */     this.gc = new GridBagConstraints();
/*  350:     */     
/*  351:     */ 
/*  352:     */ 
/*  353: 485 */     this.inpPanel.setLayout(this.gb);
/*  354:     */     
/*  355:     */ 
/*  356:     */ 
/*  357:     */ 
/*  358:     */ 
/*  359:     */ 
/*  360:     */ 
/*  361:     */ 
/*  362: 494 */     this.firstFlag = true;
/*  363:     */     
/*  364: 496 */     this.lunarFlag = lunarFlag;
/*  365:     */     
/*  366:     */ 
/*  367:     */ 
/*  368: 500 */     this.eretzFlag = true;
/*  369:     */     
/*  370: 502 */     addWindowListener(this);
/*  371:     */     
/*  372: 504 */     this.mbar = new JMenuBar();
/*  373: 505 */     this.inpframe.setJMenuBar(this.mbar);
/*  374:     */     
/*  375: 507 */     this.aboutMenu = new JMenu("Help");
/*  376: 508 */     this.aboutMenu.setFont(new Font("Arial", 1, 12));
/*  377: 509 */     this.mbar.add(this.aboutMenu);
/*  378:     */     
/*  379:     */ 
/*  380: 512 */     this.m1 = new JMenuItem("Help");
/*  381: 513 */     this.m1.setFont(new Font("Arial", 1, 12));
/*  382:     */     
/*  383: 515 */     this.m1.addActionListener(this);
/*  384: 516 */     this.aboutMenu.add(this.m1);
/*  385:     */     
/*  386: 518 */     this.m2 = new JMenuItem("About this program");
/*  387: 519 */     this.m2.setFont(new Font("Arial", 1, 12));
/*  388: 520 */     this.m2.addActionListener(this);
/*  389: 521 */     this.aboutMenu.add(this.m2);
/*  390:     */     
/*  391:     */ 
/*  392:     */ 
/*  393:     */ 
/*  394:     */ 
/*  395:     */ 
/*  396:     */ 
/*  397:     */ 
/*  398:     */ 
/*  399:     */ 
/*  400:     */ 
/*  401:     */ 
/*  402:     */ 
/*  403:     */ 
/*  404:     */ 
/*  405: 537 */     this.gc.gridx = 0;
/*  406: 538 */     this.gc.gridy = 0;
/*  407: 539 */     this.gc.gridwidth = 3;
/*  408: 540 */     this.gc.gridheight = 1;
/*  409: 541 */     this.gc.weightx = 1.0D;
/*  410: 542 */     this.gc.weighty = 1.0D;
/*  411:     */     
/*  412: 544 */     this.gc.anchor = 17;
/*  413:     */     
/*  414: 546 */     this.gc.insets = new Insets(0, 0, 0, 15);
/*  415:     */     
/*  416:     */ 
/*  417:     */ 
/*  418: 550 */     this.helplab = new JLabel("Enter Month and Year for Search", 2);
/*  419:     */     
/*  420: 552 */     this.helplab.setFont(new Font("Arial", 1, 12));
/*  421: 553 */     this.helplab.setForeground(Color.BLACK);
/*  422:     */     
/*  423:     */ 
/*  424: 556 */     this.inpPanel.add(this.helplab, this.gc);
/*  425:     */     
/*  426:     */ 
/*  427:     */ 
/*  428:     */ 
/*  429:     */ 
/*  430:     */ 
/*  431:     */ 
/*  432:     */ 
/*  433:     */ 
/*  434:     */ 
/*  435:     */ 
/*  436:     */ 
/*  437:     */ 
/*  438:     */ 
/*  439:     */ 
/*  440:     */ 
/*  441:     */ 
/*  442:     */ 
/*  443:     */ 
/*  444:     */ 
/*  445:     */ 
/*  446:     */ 
/*  447:     */ 
/*  448:     */ 
/*  449:     */ 
/*  450:     */ 
/*  451: 583 */     SearchingDate();
/*  452:     */     
/*  453:     */ 
/*  454:     */ 
/*  455:     */ 
/*  456: 588 */     this.b2 = new JButton("Calculate");
/*  457: 589 */     this.b2.addActionListener(this);
/*  458: 590 */     this.b2.setFont(new Font("Arial", 1, 12));
/*  459:     */     
/*  460: 592 */     this.gc.anchor = 10;
/*  461: 593 */     this.gc.gridx = 0;
/*  462: 594 */     this.gc.gridy = 5;
/*  463: 595 */     this.gc.gridwidth = 4;
/*  464: 596 */     this.gc.gridheight = 1;
/*  465:     */     
/*  466: 598 */     this.inpPanel.add(this.b2, this.gc);
/*  467:     */     
/*  468:     */ 
/*  469: 601 */     this.b1 = new JButton("Close");
/*  470: 602 */     this.b1.addActionListener(this);
/*  471: 603 */     this.b1.setFont(new Font("Arial", 1, 12));
/*  472:     */     
/*  473:     */ 
/*  474: 606 */     this.gc.gridy = -1;
/*  475:     */     
/*  476: 608 */     this.gc.gridheight = 1;
/*  477:     */     
/*  478: 610 */     this.inpPanel.add(this.b1, this.gc);
/*  479:     */     
/*  480:     */ 
/*  481:     */ 
/*  482:     */ 
/*  483:     */ 
/*  484:     */ 
/*  485:     */ 
/*  486:     */ 
/*  487: 619 */     this.inpframe.pack();
/*  488: 620 */     this.inpframe.setVisible(true);
/*  489:     */   }
/*  490:     */   
/*  491:     */   public boolean isLunar()
/*  492:     */   {
/*  493: 626 */     return this.lunarFlag;
/*  494:     */   }
/*  495:     */   
/*  496:     */   public static boolean getLunarFlag()
/*  497:     */   {
/*  498: 633 */     return lFlag;
/*  499:     */   }
/*  500:     */   
/*  501:     */   public void calculateDate()
/*  502:     */   {
/*  503: 641 */     CalSolarYear = 1;
/*  504: 642 */     lFlag = this.lunarFlag;
/*  505:     */     
/*  506:     */ 
/*  507:     */ 
/*  508:     */ 
/*  509: 647 */     CalSolarYear = this.searchYear;
/*  510: 650 */     if (this.lunarFlag)
/*  511:     */     {
/*  512: 652 */       LunarYear targLunYear = new LunarYear(this.searchYear, this.lunarFlag);
/*  513:     */       
/*  514: 654 */       int AdBc = 0;
/*  515: 659 */       if (targLunYear.getYear() > 3761) {
/*  516: 659 */         AdBc = 1;
/*  517:     */       }
/*  518: 661 */       SolarYear targSolYear = new SolarYear(targLunYear.getYear() - 3762 + AdBc);
/*  519:     */       
/*  520:     */ 
/*  521:     */ 
/*  522:     */ 
/*  523: 666 */       AdBc = 0;
/*  524: 667 */       if (targLunYear.getYear() > 3760) {
/*  525: 667 */         AdBc = 1;
/*  526:     */       }
/*  527: 671 */       SolarYear nextSolYear = new SolarYear(targLunYear.getYear() - 3761 + AdBc);
/*  528:     */       
/*  529:     */ 
/*  530:     */ 
/*  531:     */ 
/*  532:     */ 
/*  533:     */ 
/*  534: 678 */       targSolYear.getMonth(11).getDay(30).setNext(nextSolYear.getMonth(0).getDay(0));
/*  535:     */       
/*  536:     */ 
/*  537:     */ 
/*  538:     */ 
/*  539: 683 */       targLunYear.connect(nextSolYear);
/*  540:     */       
/*  541: 685 */       targLunYear.setHagim(this.eretzFlag);
/*  542: 689 */       if (targLunYear.isLeap()) {
/*  543: 690 */         this.leapFlag = true;
/*  544:     */       } else {
/*  545: 692 */         this.leapFlag = false;
/*  546:     */       }
/*  547: 693 */       if (!this.leapFlag)
/*  548:     */       {
/*  549: 695 */         if (((this.firstFlag) || (this.lastLeapFlag)) && (this.searchMonth >= 6)) {
/*  550: 696 */           this.searchMonth -= 1;
/*  551:     */         }
/*  552: 697 */         if ((!this.firstFlag) && (this.searchMonth == 12) && (this.backFlag)) {
/*  553: 698 */           this.searchMonth -= 1;
/*  554:     */         }
/*  555:     */       }
/*  556: 700 */       else if ((!this.lastLeapFlag) && (!this.firstFlag) && (this.searchMonth >= 6))
/*  557:     */       {
/*  558: 701 */         this.searchMonth += 1;
/*  559:     */       }
/*  560: 702 */       this.lastLeapFlag = this.leapFlag;
/*  561: 703 */       if (this.rWin == null) {
/*  562: 705 */         this.rWin = new ResultWin(this);
/*  563:     */       }
/*  564: 708 */       this.rWin.redraw(targLunYear.getMonth(this.searchMonth));
/*  565:     */     }
/*  566:     */     else
/*  567:     */     {
/*  568: 715 */       SolarYear targSolYear = new SolarYear(this.searchYear);
/*  569:     */       
/*  570:     */ 
/*  571:     */ 
/*  572:     */ 
/*  573: 720 */       int BcAd = 0;
/*  574: 721 */       if (this.searchYear > 0) {
/*  575: 722 */         BcAd = -1;
/*  576:     */       }
/*  577: 726 */       LunarYear targLunYear = new LunarYear(targSolYear.getYear() + 3761 + BcAd, this.lunarFlag);
/*  578:     */       
/*  579:     */ 
/*  580:     */ 
/*  581:     */ 
/*  582:     */ 
/*  583:     */ 
/*  584:     */ 
/*  585:     */ 
/*  586:     */ 
/*  587: 736 */       LunarYear nextLunYear = new LunarYear(targLunYear.getYear() + 1, this.lunarFlag);
/*  588:     */       
/*  589: 738 */       targLunYear.getMonth(targLunYear.getNMths() - 1).getDay(28).setNext(nextLunYear.getMonth(0).getDay(0));
/*  590: 739 */       targSolYear.connect(targLunYear);
/*  591: 740 */       targLunYear.getMonth(targLunYear.getNMths() - 1).getDay(28).setNext(null);
/*  592: 741 */       targLunYear.setHagim(this.eretzFlag);
/*  593: 742 */       nextLunYear.setHagim(this.eretzFlag);
/*  594: 743 */       targLunYear.getMonth(targLunYear.getNMths() - 1).getDay(28).setNext(nextLunYear.getMonth(0).getDay(0));
/*  595: 744 */       if (this.rWin == null) {
/*  596: 746 */         this.rWin = new ResultWin(this);
/*  597:     */       }
/*  598: 762 */       this.rWin.redraw(targSolYear.getMonth(this.searchMonth));
/*  599:     */     }
/*  600:     */   }
/*  601:     */   
/*  602:     */   public Insets getInsets()
/*  603:     */   {
/*  604: 899 */     return new Insets(50, 10, 35, 10);
/*  605:     */   }
/*  606:     */   
/*  607:     */   public int getSearchYear()
/*  608:     */   {
/*  609: 904 */     return this.searchYear;
/*  610:     */   }
/*  611:     */   
/*  612:     */   public void incrSearchMonth(int n)
/*  613:     */   {
/*  614: 920 */     int maxMth = 11 + ((!this.lunarFlag) || (!this.leapFlag) ? 0 : 1);
/*  615: 921 */     if (n <= maxMth)
/*  616:     */     {
/*  617: 923 */       this.firstFlag = false;
/*  618: 924 */       this.backFlag = false;
/*  619: 925 */       for (this.searchMonth += n; this.searchMonth > maxMth;)
/*  620:     */       {
/*  621: 927 */         this.searchMonth -= maxMth + 1;
/*  622: 928 */         this.searchYear += 1;
/*  623:     */       }
/*  624: 930 */       if ((!this.lunarFlag) && (this.searchYear == 0)) {
/*  625: 930 */         this.searchYear = 1;
/*  626:     */       }
/*  627:     */     }
/*  628:     */   }
/*  629:     */   
/*  630:     */   public void decrSearchMonth(int n)
/*  631:     */   {
/*  632: 945 */     int maxMth = 11 + ((!this.lunarFlag) || (!this.leapFlag) ? 0 : 1);
/*  633: 946 */     if (n <= maxMth)
/*  634:     */     {
/*  635: 948 */       this.firstFlag = false;
/*  636: 949 */       this.backFlag = true;
/*  637: 950 */       for (this.searchMonth -= n; this.searchMonth < 0;)
/*  638:     */       {
/*  639: 952 */         this.searchMonth += maxMth + 1;
/*  640: 953 */         this.searchYear -= 1;
/*  641:     */       }
/*  642: 957 */       if ((!this.lunarFlag) && (this.searchYear == 0)) {
/*  643: 957 */         this.searchYear = -1;
/*  644:     */       }
/*  645:     */     }
/*  646:     */   }
/*  647:     */   
/*  648:     */   public void actionPerformed(ActionEvent evt)
/*  649:     */   {
/*  650: 973 */     Object source = evt.getSource();
/*  651: 979 */     if (evt.getSource() == this.m1) {
/*  652: 981 */       this.hWin = new HelpWin("MthYrHelp");
/*  653:     */     }
/*  654: 985 */     if (evt.getSource() == this.m2) {
/*  655: 987 */       this.abWin = new AboutWind();
/*  656:     */     }
/*  657: 991 */     if (evt.getSource() == this.b1) {
/*  658: 993 */       this.inpframe.hide();
/*  659:     */     }
/*  660: 999 */     if (evt.getSource() == this.b2)
/*  661:     */     {
/*  662:1011 */       setSearchMonth();
/*  663:1012 */       this.searchYear = 1;
/*  664:1013 */       setSearchYear(getInpYear());
/*  665:1014 */       calculateDate();
/*  666:     */       
/*  667:     */ 
/*  668:     */ 
/*  669:1018 */       this.inpframe.hide();
/*  670:     */     }
/*  671:     */   }
/*  672:     */   
/*  673:     */   public int getSearchMonth()
/*  674:     */   {
/*  675:1064 */     return this.searchMonth;
/*  676:     */   }
/*  677:     */   
/*  678:     */   public boolean isEretz()
/*  679:     */   {
/*  680:1069 */     return this.eretzFlag;
/*  681:     */   }
/*  682:     */   
/*  683:     */   public void incrSearchYear(int n)
/*  684:     */   {
/*  685:1074 */     int maxMth = 11 + (this.lunarFlag ? 1 : 0);
/*  686:1075 */     this.firstFlag = false;
/*  687:1076 */     this.backFlag = false;
/*  688:1077 */     this.searchYear += n;
/*  689:1079 */     if ((!this.lunarFlag) && (this.searchYear == 0)) {
/*  690:1079 */       this.searchYear = 1;
/*  691:     */     }
/*  692:     */   }
/*  693:     */   
/*  694:     */   public void decrSearchYear(int n)
/*  695:     */   {
/*  696:1090 */     int maxMth = 11 + (this.lunarFlag ? 1 : 0);
/*  697:1091 */     this.firstFlag = false;
/*  698:1092 */     this.backFlag = false;
/*  699:1093 */     this.searchYear -= n;
/*  700:1095 */     if ((!this.lunarFlag) && (this.searchYear == 0)) {
/*  701:1095 */       this.searchYear = -1;
/*  702:     */     }
/*  703:     */   }
/*  704:     */   
/*  705:     */   public void setSearchYear(int n)
/*  706:     */   {
/*  707:1134 */     this.searchYear = 1;
/*  708:1137 */     if (!this.lunarFlag) {
/*  709:1139 */       if (this.chkbxAD.isSelected() == true)
/*  710:     */       {
/*  711:1140 */         if (n < 0) {
/*  712:1140 */           this.searchYear = (-n);
/*  713:     */         } else {
/*  714:1141 */           this.searchYear = n;
/*  715:     */         }
/*  716:     */       }
/*  717:1144 */       else if (n > 0) {
/*  718:1144 */         this.searchYear = (-n);
/*  719:     */       } else {
/*  720:1145 */         this.searchYear = n;
/*  721:     */       }
/*  722:     */     }
/*  723:1152 */     if ((n == 0) || (n == 0)) {
/*  724:1153 */       this.searchYear = 1;
/*  725:     */     }
/*  726:1162 */     if (this.lunarFlag)
/*  727:     */     {
/*  728:1164 */       int MonthIndex = this.monthMenu.getSelectedIndex();
/*  729:1168 */       if ((this.chkbxAD.isSelected() == true) && (MonthIndex < 5)) {
/*  730:1169 */         this.searchYear = (3760 + n + 1);
/*  731:1171 */       } else if ((this.chkbxAD.isSelected() == true) && (MonthIndex >= 5)) {
/*  732:1172 */         this.searchYear = (3760 + n);
/*  733:     */       }
/*  734:1175 */       if ((this.chkbxBC.isSelected() == true) && (MonthIndex < 5)) {
/*  735:1176 */         this.searchYear = (3761 - n + 1);
/*  736:1179 */       } else if ((this.chkbxBC.isSelected() == true) && (MonthIndex >= 5)) {
/*  737:1180 */         this.searchYear = (3761 - n);
/*  738:     */       }
/*  739:     */     }
/*  740:1185 */     if ((n == 0) || (n == 0)) {
/*  741:1186 */       this.searchYear = 1;
/*  742:     */     }
/*  743:     */   }
/*  744:     */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     SelectWin
 * JD-Core Version:    0.7.1
 */