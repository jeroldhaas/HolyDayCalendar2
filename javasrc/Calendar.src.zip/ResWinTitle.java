/*   1:    */ import java.awt.Canvas;
/*   2:    */ import java.awt.Color;
/*   3:    */ import java.awt.Dimension;
/*   4:    */ import java.awt.Font;
/*   5:    */ import java.awt.FontMetrics;
/*   6:    */ import java.awt.Graphics;
/*   7:    */ 
/*   8:    */ public class ResWinTitle
/*   9:    */   extends Canvas
/*  10:    */ {
/*  11:    */   public static int CalSolarYear;
/*  12:    */   public static String CalSolYearADBC;
/*  13:    */   protected Month month;
/*  14:    */   
/*  15:    */   public void setMonth(Month month)
/*  16:    */   {
/*  17: 16 */     this.month = month;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public Month getMonth()
/*  21:    */   {
/*  22: 21 */     return this.month;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public ResWinTitle() {}
/*  26:    */   
/*  27:    */   public static int getCalSolarYear()
/*  28:    */   {
/*  29: 32 */     return CalSolarYear;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static String getCalSolYearADBC()
/*  33:    */   {
/*  34: 38 */     return CalSolYearADBC;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public ResWinTitle(Month month)
/*  38:    */   {
/*  39: 44 */     this.month = month;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void paint(Graphics g)
/*  43:    */   {
/*  44: 64 */     CalSolarYear = 1;
/*  45: 65 */     CalSolYearADBC = " ";
/*  46:    */     
/*  47:    */ 
/*  48: 68 */     Font f = new Font("Arial", 1, 14);
/*  49:    */     
/*  50: 70 */     FontMetrics fm = getFontMetrics(f);
/*  51:    */     
/*  52:    */ 
/*  53: 73 */     String title1 = this.month.getName() + " " + Integer.toString(this.month.getYear().getYear());
/*  54:    */     
/*  55:    */ 
/*  56: 76 */     String title2 = this.month.getDay(0).getOther().getMonth().getName();
/*  57:    */     
/*  58:    */ 
/*  59: 79 */     String title3 = this.month.getDay(this.month.getNDays() - 1).getOther().getMonth().getName();
/*  60:    */     
/*  61: 81 */     int posYear = this.month.getYear().getYear();
/*  62: 86 */     if ((this.month.getYear() instanceof SolarYear)) {
/*  63: 88 */       if (this.month.getYear().getYear() > 0)
/*  64:    */       {
/*  65: 91 */         CalSolarYear = posYear;
/*  66: 92 */         CalSolYearADBC = "AD";
/*  67:    */         
/*  68:    */ 
/*  69: 95 */         title1 = this.month.getName() + " " + Integer.toString(posYear) + " AD";
/*  70:    */       }
/*  71:    */       else
/*  72:    */       {
/*  73:100 */         posYear *= -1;
/*  74:    */         
/*  75:102 */         CalSolarYear = posYear;
/*  76:103 */         CalSolYearADBC = "BC";
/*  77:    */         
/*  78:105 */         title1 = this.month.getName() + " " + Integer.toString(posYear) + " BC";
/*  79:    */       }
/*  80:    */     }
/*  81:115 */     String Exmonth = this.month.getDay(15).getOther().getMonth().getName();
/*  82:117 */     if ((!title2.equals(Exmonth)) && (!Exmonth.equals(title3))) {
/*  83:118 */       title2 = title2.concat("/" + Exmonth);
/*  84:    */     }
/*  85:120 */     if (!title2.equals(title3)) {
/*  86:121 */       title2 = title2.concat("/" + title3);
/*  87:    */     }
/*  88:127 */     posYear = this.month.getDay(this.month.getNDays() - 1).getOther().getMonth().getYear().getYear();
/*  89:130 */     if ((this.month.getYear() instanceof SolarYear)) {
/*  90:131 */       title2 = title2.concat(" " + Integer.toString(posYear));
/*  91:    */     }
/*  92:141 */     if ((this.month.getYear() instanceof LunarYear)) {
/*  93:143 */       if (posYear > 0)
/*  94:    */       {
/*  95:145 */         CalSolarYear = posYear;
/*  96:146 */         CalSolYearADBC = "BC";
/*  97:    */         
/*  98:148 */         title2 = title2.concat(" " + Integer.toString(posYear) + " AD");
/*  99:    */       }
/* 100:    */       else
/* 101:    */       {
/* 102:151 */         posYear *= -1;
/* 103:    */         
/* 104:153 */         CalSolarYear = posYear;
/* 105:154 */         CalSolYearADBC = "BC";
/* 106:    */         
/* 107:    */ 
/* 108:157 */         title2 = title2.concat(" " + Integer.toString(posYear) + " BC");
/* 109:    */       }
/* 110:    */     }
/* 111:164 */     setBackground(new Color(192, 192, 192));
/* 112:165 */     g.setFont(f);
/* 113:166 */     g.setColor(Color.blue);
/* 114:    */     
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:172 */     g.drawString(title1, 4, fm.getHeight() + 10);
/* 120:    */     
/* 121:174 */     g.setFont(f);
/* 122:175 */     g.setColor(Color.red);
/* 123:176 */     g.drawString(title2, getSize().width - fm.stringWidth(title2) - 4, fm.getHeight() + 10);
/* 124:    */   }
/* 125:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     ResWinTitle
 * JD-Core Version:    0.7.1
 */