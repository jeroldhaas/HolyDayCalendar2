/*   1:    */ import java.awt.Color;
/*   2:    */ import java.awt.Dimension;
/*   3:    */ import java.awt.Font;
/*   4:    */ import java.awt.GridBagLayout;
/*   5:    */ import java.awt.Insets;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import javax.swing.ButtonGroup;
/*   9:    */ import javax.swing.JApplet;
/*  10:    */ import javax.swing.JButton;
/*  11:    */ import javax.swing.JCheckBox;
/*  12:    */ import javax.swing.JLabel;
/*  13:    */ import javax.swing.JPanel;
/*  14:    */ import javax.swing.JTextField;
/*  15:    */ import javax.swing.border.EmptyBorder;
/*  16:    */ import javax.swing.border.LineBorder;
/*  17:    */ 
/*  18:    */ public class Calendar
/*  19:    */   extends JApplet
/*  20:    */   implements ActionListener
/*  21:    */ {
/*  22:    */   JPanel ConPane;
/*  23:    */   JLabel Title1;
/*  24:    */   JLabel Title2;
/*  25:    */   JLabel la;
/*  26:    */   JTextField yearField;
/*  27:    */   ButtonGroup cbg;
/*  28:    */   JCheckBox chkbxAD;
/*  29:    */   JCheckBox chkbxBC;
/*  30:    */   JButton e;
/*  31:    */   JButton b;
/*  32:    */   JButton d;
/*  33:    */   protected HelpWin hWin;
/*  34:    */   protected HDWin hdWin;
/*  35:    */   protected AboutWind aboutWin;
/*  36:    */   
/*  37:    */   public String getAppletInfo()
/*  38:    */   {
/*  39: 34 */     return "About Holy Day Calendar\n=======================\n\nFor information\ton the history and structure of the Hebrew\nCalendar write:\n\nChristian Biblical Church of God\nP.O. Box 1442\nHollister,California\n95024-1442\n\nE-mail: FredCoulter@cbcg.org\n\n**In order to receive a reply when writing to Mr. Coulter,\nplease include your home mailing address.**\n\nWebmaster@cbcg.org\nPhone: 1-831-637-1875\nFax: 1-831-637-9616\nhttp://www.cbcg.org/\n\nOriginal Java Code created by Rafi Stern (1997-98)\nCode Changes/Additions by Alan Ruth (2003)\n\nCopyright Christian Biblical Church of God\n";
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void actionPerformed(ActionEvent evt)
/*  43:    */   {
/*  44: 54 */     Object source = evt.getSource();
/*  45:    */     boolean adFlag;
/*  46: 61 */     if (this.chkbxAD.isSelected() == true) {
/*  47: 62 */       adFlag = true;
/*  48:    */     } else {
/*  49: 64 */       adFlag = false;
/*  50:    */     }
/*  51: 73 */     if (source == this.b) {
/*  52: 76 */       this.hWin = new HelpWin("InitCal");
/*  53:    */     }
/*  54: 82 */     if (source == this.d) {
/*  55: 83 */       this.aboutWin = new AboutWind();
/*  56:    */     }
/*  57:    */     BuildPanel HDCalendarBuild;
/*  58: 91 */     if (source == this.e)
/*  59:    */     {
/*  60: 93 */       this.hdWin = new HDWin(adFlag, this.yearField.getText());
/*  61:    */       
/*  62: 95 */       boolean yearTypeFlag = HDWin.getADBCflag();
/*  63: 96 */       int HDYearInput = HDWin.getYearInput();
/*  64:    */       
/*  65: 98 */       HDCalendarBuild = new BuildPanel(yearTypeFlag, HDYearInput);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void init()
/*  70:    */   {
/*  71:134 */     this.ConPane = new JPanel();
/*  72:135 */     this.ConPane.setOpaque(true);
/*  73:    */     
/*  74:137 */     GridBagLayout gb = new GridBagLayout();
/*  75:138 */     GBConstraints gbc = new GBConstraints();
/*  76:    */     
/*  77:140 */     this.ConPane.setLayout(gb);
/*  78:    */     
/*  79:    */ 
/*  80:143 */     this.ConPane.setBorder(new LineBorder(Color.black, 2, true));
/*  81:144 */     this.ConPane.setBackground(Color.white);
/*  82:    */     
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:158 */     this.Title1 = new JLabel("Holy Day Calendar 1.0");
/*  96:159 */     this.Title1.setVerticalAlignment(1);
/*  97:    */     
/*  98:    */ 
/*  99:162 */     this.Title1.setFont(new Font("TimesRoman", 1, 24));
/* 100:163 */     this.Title1.setForeground(Color.BLUE);
/* 101:    */     
/* 102:    */ 
/* 103:166 */     gbc.gridx = 0;
/* 104:167 */     gbc.gridy = 0;
/* 105:168 */     gbc.gridwidth = 6;
/* 106:169 */     gbc.gridheight = 1;
/* 107:    */     
/* 108:171 */     gbc.weightx = 1.0D;
/* 109:172 */     gbc.weighty = 1.0D;
/* 110:    */     
/* 111:174 */     gbc.anchor = 11;
/* 112:    */     
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:179 */     gbc.insets = new Insets(0, 0, 0, 0);
/* 117:180 */     gb.setConstraints(this.Title1, gbc);
/* 118:181 */     this.ConPane.add(this.Title1);
/* 119:    */     
/* 120:    */ 
/* 121:184 */     gbc.gridy = 1;
/* 122:185 */     gbc.gridx = 0;
/* 123:186 */     gbc.gridwidth = 6;
/* 124:187 */     gbc.gridheight = 1;
/* 125:    */     
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:192 */     this.Title2 = new JLabel("Christian Biblical Church of God");
/* 130:193 */     this.Title2.setFont(new Font("TimesRoman", 2, 16));
/* 131:194 */     this.Title2.setVerticalAlignment(1);
/* 132:195 */     this.Title2.setForeground(Color.BLUE);
/* 133:    */     
/* 134:    */ 
/* 135:198 */     gb.setConstraints(this.Title2, gbc);
/* 136:    */     
/* 137:200 */     this.ConPane.add(this.Title2);
/* 138:    */     
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:225 */     EmptyBorder border = new EmptyBorder(new Insets(0, 5, 0, 0));
/* 163:226 */     this.la = new JLabel("Enter Year:");
/* 164:227 */     this.la.setBorder(border);
/* 165:    */     
/* 166:229 */     this.la.setFont(new Font("TimesRoman", 1, 14));
/* 167:230 */     this.la.setForeground(Color.BLACK);
/* 168:    */     
/* 169:232 */     gbc.gridwidth = 1;
/* 170:    */     
/* 171:234 */     gbc.gridx = 0;
/* 172:235 */     gbc.gridy = 3;
/* 173:    */     
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:243 */     gb.setConstraints(this.la, gbc);
/* 181:244 */     this.ConPane.add(this.la);
/* 182:    */     
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:250 */     this.yearField = new JTextField();
/* 188:    */     
/* 189:252 */     this.yearField.setBorder(new LineBorder(Color.black, 1, true));
/* 190:    */     
/* 191:254 */     Dimension shortfield = new Dimension(50, 20);
/* 192:255 */     this.yearField.setPreferredSize(shortfield);
/* 193:    */     
/* 194:257 */     gbc.gridx = 1;
/* 195:258 */     gbc.gridy = 3;
/* 196:259 */     gbc.gridwidth = 1;
/* 197:    */     
/* 198:    */ 
/* 199:262 */     gbc.weightx = 1.0D;
/* 200:    */     
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:270 */     gb.setConstraints(this.yearField, gbc);
/* 208:271 */     this.ConPane.add(this.yearField);
/* 209:    */     
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:276 */     this.cbg = new ButtonGroup();
/* 214:    */     
/* 215:278 */     gbc.gridx = 2;
/* 216:279 */     gbc.gridy = 3;
/* 217:280 */     gbc.gridwidth = 1;
/* 218:    */     
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:291 */     this.chkbxBC = new JCheckBox("BC", false);
/* 229:292 */     this.chkbxBC.setBackground(Color.white);
/* 230:    */     
/* 231:    */ 
/* 232:    */ 
/* 233:296 */     this.ConPane.add(this.chkbxBC, gbc);
/* 234:    */     
/* 235:298 */     this.cbg.add(this.chkbxBC);
/* 236:    */     
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:303 */     gbc.gridx = -1;
/* 241:304 */     gbc.gridy = 3;
/* 242:    */     
/* 243:    */ 
/* 244:    */ 
/* 245:    */ 
/* 246:    */ 
/* 247:310 */     this.chkbxAD = new JCheckBox("AD", true);
/* 248:311 */     this.chkbxAD.setBackground(Color.white);
/* 249:    */     
/* 250:    */ 
/* 251:    */ 
/* 252:    */ 
/* 253:    */ 
/* 254:317 */     this.ConPane.add(this.chkbxAD, gbc);
/* 255:    */     
/* 256:319 */     this.cbg.add(this.chkbxAD);
/* 257:    */     
/* 258:    */ 
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:328 */     this.b = new JButton("Help");
/* 266:329 */     gbc.gridx = 5;
/* 267:330 */     gbc.gridy = 2;
/* 268:331 */     gbc.gridwidth = 1;
/* 269:    */     
/* 270:    */ 
/* 271:334 */     gb.setConstraints(this.b, gbc);
/* 272:335 */     this.ConPane.add(this.b);
/* 273:336 */     this.b.addActionListener(this);
/* 274:    */     
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:342 */     this.d = new JButton("About");
/* 280:343 */     gbc.gridx = 5;
/* 281:344 */     gbc.gridy = 4;
/* 282:345 */     gbc.gridwidth = 1;
/* 283:    */     
/* 284:    */ 
/* 285:348 */     gb.setConstraints(this.d, gbc);
/* 286:349 */     this.ConPane.add(this.d);
/* 287:350 */     this.d.addActionListener(this);
/* 288:    */     
/* 289:    */ 
/* 290:353 */     this.e = new JButton("Get Calendar");
/* 291:354 */     gbc.gridheight = 1;
/* 292:355 */     gbc.anchor = 10;
/* 293:356 */     gbc.gridx = 0;
/* 294:357 */     gbc.gridy = 6;
/* 295:358 */     gbc.gridwidth = 6;
/* 296:    */     
/* 297:360 */     gbc.weighty = 1.0D;
/* 298:361 */     gbc.insets = new Insets(0, 0, 0, 0);
/* 299:362 */     this.ConPane.add(this.e, gbc);
/* 300:363 */     this.e.addActionListener(this);
/* 301:    */     
/* 302:    */ 
/* 303:    */ 
/* 304:    */ 
/* 305:    */ 
/* 306:    */ 
/* 307:    */ 
/* 308:    */ 
/* 309:    */ 
/* 310:    */ 
/* 311:    */ 
/* 312:    */ 
/* 313:376 */     this.ConPane.setOpaque(true);
/* 314:    */     
/* 315:    */ 
/* 316:    */ 
/* 317:    */ 
/* 318:381 */     setContentPane(this.ConPane);
/* 319:    */   }
/* 320:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     Calendar
 * JD-Core Version:    0.7.1
 */