/*   1:    */ import java.awt.BorderLayout;
/*   2:    */ import java.awt.Color;
/*   3:    */ import java.awt.Dimension;
/*   4:    */ import java.awt.Font;
/*   5:    */ import java.awt.GridBagConstraints;
/*   6:    */ import java.awt.GridBagLayout;
/*   7:    */ import java.awt.Insets;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.awt.event.ActionListener;
/*  10:    */ import java.awt.event.WindowEvent;
/*  11:    */ import java.awt.event.WindowListener;
/*  12:    */ import javax.swing.BoxLayout;
/*  13:    */ import javax.swing.JButton;
/*  14:    */ import javax.swing.JFrame;
/*  15:    */ import javax.swing.JLabel;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import javax.swing.JScrollPane;
/*  18:    */ import javax.swing.JTextArea;
/*  19:    */ 
/*  20:    */ public class HelpWin
/*  21:    */   extends JFrame
/*  22:    */   implements ActionListener, WindowListener
/*  23:    */ {
/*  24:    */   JPanel contPane;
/*  25:    */   JPanel ButtonArea;
/*  26:    */   JPanel scArea;
/*  27:    */   JTextArea textArea;
/*  28:    */   JLabel HTitle;
/*  29:    */   JLabel HText;
/*  30:    */   JFrame popframe;
/*  31:    */   private JButton ClosingButton;
/*  32:    */   GridBagLayout gridbag;
/*  33:    */   GridBagConstraints c;
/*  34:    */   
/*  35:    */   public HelpWin(String HelpType)
/*  36:    */   {
/*  37: 30 */     super("Holy Day Calendar Help");
/*  38:    */     
/*  39: 32 */     this.popframe = new JFrame("Holy Day Calendar Help");
/*  40: 33 */     this.popframe.addWindowListener(this);
/*  41:    */     
/*  42: 35 */     this.popframe.setSize(400, 300);
/*  43:    */     
/*  44: 37 */     this.popframe.setDefaultCloseOperation(1);
/*  45: 38 */     this.contPane = new JPanel();
/*  46:    */     
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50: 43 */     this.contPane.setLayout(new BorderLayout(5, 7));
/*  51: 44 */     this.contPane.setSize(400, 300);
/*  52:    */     
/*  53:    */ 
/*  54:    */ 
/*  55: 48 */     this.contPane.setBackground(Color.white);
/*  56: 49 */     this.popframe.setContentPane(this.contPane);
/*  57: 50 */     this.contPane.setOpaque(true);
/*  58:    */     
/*  59:    */ 
/*  60:    */ 
/*  61: 54 */     this.scArea = new JPanel();
/*  62: 55 */     this.scArea.setOpaque(true);
/*  63: 56 */     this.scArea.setBackground(Color.white);
/*  64:    */     
/*  65:    */ 
/*  66: 59 */     this.scArea.setLayout(new BoxLayout(this.scArea, 1));
/*  67:    */     
/*  68:    */ 
/*  69: 62 */     this.ButtonArea = new JPanel();
/*  70: 63 */     this.ButtonArea.setOpaque(true);
/*  71: 64 */     this.ButtonArea.setBackground(Color.white);
/*  72:    */     
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77: 70 */     this.gridbag = new GridBagLayout();
/*  78: 71 */     this.c = new GridBagConstraints();
/*  79:    */     
/*  80: 73 */     this.ButtonArea.setLayout(this.gridbag);
/*  81:    */     
/*  82:    */ 
/*  83: 76 */     this.c.gridx = 1;
/*  84: 77 */     this.c.gridy = 0;
/*  85: 78 */     this.c.gridwidth = 1;
/*  86:    */     
/*  87: 80 */     this.c.anchor = 10;
/*  88: 81 */     this.c.gridheight = 1;
/*  89:    */     
/*  90: 83 */     this.c.weightx = 1.0D;
/*  91: 84 */     this.c.weighty = 1.0D;
/*  92:    */     
/*  93: 86 */     this.c.insets = new Insets(3, 0, 3, 0);
/*  94: 94 */     if (HelpType == "InitCal")
/*  95:    */     {
/*  96: 97 */       this.HTitle = new JLabel("Holy Day Calendar Help", 0);
/*  97:    */       
/*  98:    */ 
/*  99:100 */       this.HTitle.setFont(new Font("Arial", 1, 14));
/* 100:101 */       this.HTitle.setPreferredSize(new Dimension(400, 25));
/* 101:102 */       this.HTitle.setMinimumSize(new Dimension(400, 25));
/* 102:    */       
/* 103:    */ 
/* 104:    */ 
/* 105:106 */       this.contPane.add(this.HTitle, "North");
/* 106:    */       
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:114 */       this.textArea = new JTextArea("This Holy Day Calendar displays either Hebrew or Roman dates for any given year BC or AD from 3761 BC well into the future AD.\n\nTo retrieve a date AD or BC, enter the year in the \"Enter Year\" box, select AD or BC, and click on \"Get Calendar\" button. A six-month pop-up screen will appear with highlighted dates for the spring and fall holy days.\n\n\n\n\n");
/* 114:    */     }
/* 115:132 */     else if (HelpType == "MthYrHelp")
/* 116:    */     {
/* 117:134 */       this.HTitle = new JLabel("Holy Day Calendar Help", 0);
/* 118:    */       
/* 119:136 */       this.HTitle.setFont(new Font("Arial", 1, 14));
/* 120:137 */       this.HTitle.setPreferredSize(new Dimension(400, 25));
/* 121:138 */       this.HTitle.setMinimumSize(new Dimension(400, 25));
/* 122:    */       
/* 123:    */ 
/* 124:    */ 
/* 125:142 */       this.contPane.add(this.HTitle, "North");
/* 126:    */       
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:149 */       this.textArea = new JTextArea("Window Overview\n===============\nIn this window you select the month and year you wish to display.\n\nHow to Select\n=============\n1. Select month\n2. Enter year in text field\n3. Click on 'Calculate' button\n\nThis will open results window.\n\n");
/* 133:    */     }
/* 134:159 */     else if (HelpType == "monthCal")
/* 135:    */     {
/* 136:161 */       this.HTitle = new JLabel("Holy Day Calendar Help", 0);
/* 137:162 */       this.HTitle.setFont(new Font("Arial", 1, 14));
/* 138:163 */       this.HTitle.setPreferredSize(new Dimension(400, 25));
/* 139:164 */       this.HTitle.setMinimumSize(new Dimension(400, 25));
/* 140:    */       
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:171 */       this.contPane.add(this.HTitle, "North");
/* 147:    */       
/* 148:    */ 
/* 149:    */ 
/* 150:175 */       this.textArea = new JTextArea("Window Overview\n===============\nThis window displays the calendar for the month and year that you have selected.\n\nThe calendar displayed is browseable. Use the arrow keys to browse backwards and forwards by single or multiple increments of months or years.\n\nThe days are color coded to show Holy Days. Move the cursor over a color coded day and read the text in the window's status bar in order to see which Holy Day it is.\n\nTo Browse\n=========\nThere are two sets of browsing buttons located beneath the calendar: \n\n1. Enter the size of the increment in the appropriate text field.\n2. Use the buttons to browse backwards or forwards.\n\nYou may enter in the 'months' field any positive number of months between 1 and 11.\n\nYou may enter in the 'years' any positive number of years.\n\nTo Print\n=========\n1. Copy calendar by hitting 'Alt' - 'PrintScreen'  keys at same time.\n2. Open word processing program such as MS-Word or WordPad.\n3. Do a 'Paste' inside word processing program.\n4. Print.\n\n");
/* 151:    */     }
/* 152:232 */     this.textArea.setEditable(false);
/* 153:    */     
/* 154:234 */     this.textArea.setLineWrap(true);
/* 155:235 */     this.textArea.setWrapStyleWord(true);
/* 156:236 */     this.textArea.setFont(new Font("Arial", 0, 12));
/* 157:    */     
/* 158:238 */     this.textArea.setAlignmentX(0.5F);
/* 159:239 */     this.textArea.setMargin(new Insets(0, 3, 0, 3));
/* 160:    */     
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:244 */     JScrollPane scrllPane = new JScrollPane(this.textArea);
/* 165:245 */     scrllPane.setSize(new Dimension(400, 300));
/* 166:    */     
/* 167:247 */     scrllPane.setVerticalScrollBarPolicy(20);
/* 168:248 */     scrllPane.setHorizontalScrollBarPolicy(30);
/* 169:    */     
/* 170:    */ 
/* 171:251 */     this.scArea.setAlignmentX(0.5F);
/* 172:252 */     this.scArea.add(scrllPane);
/* 173:    */     
/* 174:254 */     this.contPane.add(this.scArea, "Center");
/* 175:    */     
/* 176:    */ 
/* 177:    */ 
/* 178:258 */     this.ClosingButton = new JButton("Close");
/* 179:259 */     this.ClosingButton.addActionListener(this);
/* 180:    */     
/* 181:261 */     this.ClosingButton.setPreferredSize(new Dimension(150, 20));
/* 182:262 */     this.ClosingButton.setMinimumSize(new Dimension(150, 20));
/* 183:263 */     this.ClosingButton.setFont(new Font("Arial", 1, 12));
/* 184:264 */     this.ClosingButton.setMargin(new Insets(1, 0, 1, 0));
/* 185:    */     
/* 186:    */ 
/* 187:    */ 
/* 188:268 */     this.ButtonArea.add(this.ClosingButton, this.c);
/* 189:    */     
/* 190:270 */     this.contPane.add(this.ButtonArea, "South");
/* 191:271 */     addWindowListener(this);
/* 192:    */     
/* 193:    */ 
/* 194:274 */     this.popframe.pack();
/* 195:    */     
/* 196:    */ 
/* 197:    */ 
/* 198:278 */     this.popframe.setVisible(true);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public void actionPerformed(ActionEvent evt)
/* 202:    */   {
/* 203:286 */     Object source = evt.getSource();
/* 204:287 */     if (source == this.ClosingButton) {
/* 205:291 */       this.popframe.hide();
/* 206:    */     }
/* 207:    */   }
/* 208:    */   
/* 209:    */   public void windowClosing(WindowEvent e)
/* 210:    */   {
/* 211:298 */     setVisible(false);
/* 212:    */   }
/* 213:    */   
/* 214:    */   public void windowClosed(WindowEvent e) {}
/* 215:    */   
/* 216:    */   public void windowOpened(WindowEvent e) {}
/* 217:    */   
/* 218:    */   public void windowIconified(WindowEvent e) {}
/* 219:    */   
/* 220:    */   public void windowDeiconified(WindowEvent e) {}
/* 221:    */   
/* 222:    */   public void windowActivated(WindowEvent e) {}
/* 223:    */   
/* 224:    */   public void windowDeactivated(WindowEvent e) {}
/* 225:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     HelpWin
 * JD-Core Version:    0.7.1
 */