/*   1:    */ public class LunarYear
/*   2:    */   extends Year
/*   3:    */ {
/*   4:    */   public static int getPesachDay(int yr, boolean lunarFlag)
/*   5:    */   {
/*   6: 12 */     int sYear = 0;
/*   7: 20 */     if (yr >= 3761) {
/*   8: 21 */       sYear = yr - 3760;
/*   9:    */     } else {
/*  10: 23 */       sYear = yr - 3761;
/*  11:    */     }
/*  12: 32 */     int a = (12 * yr + 17) % 19;
/*  13: 33 */     int b = yr % 4;
/*  14: 34 */     double mm = 32.044093199999999D + 1.5542418D * a + 0.25D * b - 0.003177794D * yr;
/*  15: 35 */     double m = mm % 1.0D;
/*  16: 36 */     int bigm = (int)mm;
/*  17: 37 */     int c = (bigm + 3 * yr + 5 * b + 5) % 7;
/*  18: 38 */     if ((c == 2) || (c == 4) || ((c == 0) && (a >= 12) && (m >= 0.8977000000000001D)))
/*  19:    */     {
/*  20: 40 */       c++;
/*  21: 41 */       bigm++;
/*  22:    */     }
/*  23: 43 */     else if (c == 6)
/*  24:    */     {
/*  25: 45 */       c = 0;
/*  26: 46 */       bigm++;
/*  27:    */     }
/*  28: 48 */     else if ((c == 1) && (a >= 7) && (m >= 0.6329D))
/*  29:    */     {
/*  30: 50 */       c += 2;
/*  31: 51 */       bigm += 2;
/*  32:    */     }
/*  33: 53 */     return c;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean isMalei()
/*  37:    */   {
/*  38: 58 */     return this.malei;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public int setPesach()
/*  42:    */   {
/*  43: 70 */     int sYear = 0;
/*  44: 72 */     if (this.year >= 3761) {
/*  45: 73 */       sYear = this.year - 3760;
/*  46:    */     } else {
/*  47: 75 */       sYear = this.year - 3761;
/*  48:    */     }
/*  49: 78 */     int a = (12 * this.year + 17) % 19;
/*  50: 79 */     int b = this.year % 4;
/*  51: 80 */     double mm = 32.044093199999999D + 1.5542418D * a + 0.25D * b - 0.003177794D * this.year;
/*  52: 81 */     double m = mm % 1.0D;
/*  53: 82 */     int bigm = (int)mm;
/*  54: 83 */     int c = (bigm + 3 * this.year + 5 * b + 5) % 7;
/*  55: 84 */     if (a > 11) {
/*  56: 85 */       this.leap = true;
/*  57:    */     } else {
/*  58: 87 */       this.leap = false;
/*  59:    */     }
/*  60: 88 */     if ((c == 2) || (c == 4) || ((c == 0) && (a >= 12) && (m >= 0.8977000000000001D)))
/*  61:    */     {
/*  62: 90 */       c++;
/*  63: 91 */       bigm++;
/*  64:    */     }
/*  65: 93 */     else if (c == 6)
/*  66:    */     {
/*  67: 95 */       c = 0;
/*  68: 96 */       bigm++;
/*  69:    */     }
/*  70: 98 */     else if ((c == 1) && (a >= 7) && (m >= 0.6329D))
/*  71:    */     {
/*  72:100 */       c += 2;
/*  73:101 */       bigm += 2;
/*  74:    */     }
/*  75:105 */     if (sYear > 1582) {
/*  76:106 */       bigm = bigm + 10 + Math.max(sYear / 100 - 16, 0) - Math.max(sYear / 400 - 4, 0);
/*  77:    */     }
/*  78:108 */     if (bigm <= 31)
/*  79:    */     {
/*  80:110 */       this.pSolMonth = 2;
/*  81:111 */       this.PassoverMonth = 2;
/*  82:    */     }
/*  83:    */     else
/*  84:    */     {
/*  85:115 */       bigm -= 31;
/*  86:116 */       this.pSolMonth = 3;
/*  87:117 */       this.PassoverMonth = 3;
/*  88:    */     }
/*  89:135 */     this.pDay = c;
/*  90:136 */     this.pSolDate = bigm;
/*  91:    */     
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:154 */     this.PassoverDay = (this.pDay - 1);
/* 109:157 */     if (this.PassoverDay < 0) {
/* 110:158 */       this.PassoverDay = 6;
/* 111:    */     }
/* 112:162 */     if (this.PassoverDay == 0) {
/* 113:164 */       this.PassoverDay = 6;
/* 114:    */     } else {
/* 115:168 */       this.PassoverDay -= 1;
/* 116:    */     }
/* 117:171 */     if (this.pSolDate == 1)
/* 118:    */     {
/* 119:173 */       this.PassoverDate = 31;
/* 120:174 */       this.PassoverMonth -= 1;
/* 121:    */     }
/* 122:    */     else
/* 123:    */     {
/* 124:178 */       this.PassoverDate = (this.pSolDate - 1);
/* 125:    */     }
/* 126:189 */     if (this.PassoverDay == 6) {
/* 127:191 */       Fdub = 0;
/* 128:    */     } else {
/* 129:195 */       Fdub = this.PassoverDay + 1;
/* 130:    */     }
/* 131:198 */     Fdtub = this.PassoverDate + 1;
/* 132:199 */     Fmub = this.PassoverMonth;
/* 133:203 */     if ((Fmub == 2) && (Fdtub > 31))
/* 134:    */     {
/* 135:205 */       Fdtub = 1;
/* 136:206 */       Fmub = 3;
/* 137:    */     }
/* 138:209 */     else if ((Fmub == 3) && (Fdtub > 30))
/* 139:    */     {
/* 140:211 */       Fdtub = 1;
/* 141:212 */       Fmub = 4;
/* 142:    */     }
/* 143:222 */     Ldub = this.PassoverDay;
/* 144:223 */     Ldtub = this.PassoverDate + 7;
/* 145:224 */     Lmub = this.PassoverMonth;
/* 146:226 */     if ((Lmub == 2) && (Ldtub > 31))
/* 147:    */     {
/* 148:228 */       Ldtub -= 31;
/* 149:229 */       Lmub = 3;
/* 150:    */     }
/* 151:232 */     else if ((Lmub == 3) && (Ldtub > 30))
/* 152:    */     {
/* 153:234 */       Ldtub -= 30;
/* 154:235 */       Lmub = 4;
/* 155:    */     }
/* 156:256 */     this.WaveHebDt = 14;
/* 157:257 */     this.PentHebDt = 0;
/* 158:    */     
/* 159:259 */     WaveDay = this.PassoverDay;
/* 160:260 */     WaveDate = this.PassoverDate;
/* 161:261 */     WaveMonth = this.PassoverMonth;
/* 162:    */     do
/* 163:    */     {
/* 164:268 */       if (WaveDay == 6)
/* 165:    */       {
/* 166:269 */         WaveDay = 0;
/* 167:270 */         this.WaveHebDt += 1;
/* 168:    */       }
/* 169:    */       else
/* 170:    */       {
/* 171:273 */         WaveDay += 1;
/* 172:274 */         this.WaveHebDt += 1;
/* 173:    */       }
/* 174:276 */       WaveDate += 1;
/* 175:279 */     } while (WaveDay != 0);
/* 176:283 */     this.PentHebDt = (30 - this.WaveHebDt + 1 + 29);
/* 177:284 */     this.PentHebDt = (50 - this.PentHebDt);
/* 178:292 */     if ((WaveMonth == 2) && (WaveDate > 31))
/* 179:    */     {
/* 180:294 */       WaveDate -= 31;
/* 181:295 */       WaveMonth = 3;
/* 182:    */     }
/* 183:298 */     else if ((WaveMonth == 3) && (WaveDate > 30))
/* 184:    */     {
/* 185:300 */       WaveDate -= 30;
/* 186:301 */       WaveMonth = 4;
/* 187:    */     }
/* 188:315 */     PentDay = 0;
/* 189:316 */     PentMonth = WaveMonth;
/* 190:317 */     PentDate = WaveDate;
/* 191:320 */     if (PentMonth == 2)
/* 192:    */     {
/* 193:322 */       PentDate = 49 - (31 - PentDate);
/* 194:323 */       PentMonth = 3;
/* 195:325 */       if (PentDate > 30)
/* 196:    */       {
/* 197:327 */         PentDate -= 30;
/* 198:328 */         PentMonth = 4;
/* 199:    */       }
/* 200:    */     }
/* 201:    */     else
/* 202:    */     {
/* 203:334 */       if (PentMonth == 3)
/* 204:    */       {
/* 205:336 */         PentDate = 49 - (30 - PentDate);
/* 206:337 */         PentMonth = 4;
/* 207:    */       }
/* 208:340 */       if (PentDate > 31)
/* 209:    */       {
/* 210:342 */         PentDate -= 31;
/* 211:343 */         PentMonth = 5;
/* 212:    */       }
/* 213:    */     }
/* 214:350 */     return c;
/* 215:    */   }
/* 216:    */   
/* 217:    */   public boolean isHaser()
/* 218:    */   {
/* 219:359 */     return this.haser;
/* 220:    */   }
/* 221:    */   
/* 222:    */   public LunarYear(int num, boolean lunarFlag)
/* 223:    */   {
/* 224:388 */     super(num);
/* 225:    */     
/* 226:390 */     int lastPesach = getPesachDay(this.year - 1, lunarFlag);
/* 227:391 */     int thisPesach = setPesach();
/* 228:    */     
/* 229:    */ 
/* 230:394 */     this.IsHebLeapYr = this.leap;
/* 231:    */     
/* 232:    */ 
/* 233:397 */     int dif = thisPesach - lastPesach;
/* 234:398 */     if (dif < 0) {
/* 235:399 */       dif += 7;
/* 236:    */     }
/* 237:400 */     switch (dif)
/* 238:    */     {
/* 239:    */     case 3: 
/* 240:403 */       this.haser = true;
/* 241:404 */       break;
/* 242:    */     case 5: 
/* 243:407 */       if (this.leap) {
/* 244:408 */         this.haser = true;
/* 245:    */       } else {
/* 246:410 */         this.malei = true;
/* 247:    */       }
/* 248:411 */       break;
/* 249:    */     case 0: 
/* 250:414 */       this.malei = true;
/* 251:    */     }
/* 252:417 */     if (this.leap)
/* 253:    */     {
/* 254:419 */       if (this.malei) {
/* 255:420 */         switch (this.pDay)
/* 256:    */         {
/* 257:    */         case 0: 
/* 258:423 */           this.yearType = 4;
/* 259:424 */           break;
/* 260:    */         case 3: 
/* 261:427 */           this.yearType = 10;
/* 262:428 */           break;
/* 263:    */         case 5: 
/* 264:431 */           this.yearType = 14;
/* 265:    */         }
/* 266:435 */       } else if (this.haser) {
/* 267:436 */         switch (this.pDay)
/* 268:    */         {
/* 269:    */         case 1: 
/* 270:439 */           this.yearType = 8;
/* 271:440 */           break;
/* 272:    */         case 3: 
/* 273:443 */           this.yearType = 12;
/* 274:444 */           break;
/* 275:    */         case 5: 
/* 276:447 */           this.yearType = 2;
/* 277:    */         }
/* 278:    */       } else {
/* 279:451 */         this.yearType = 6;
/* 280:    */       }
/* 281:    */     }
/* 282:453 */     else if (this.malei) {
/* 283:454 */       switch (this.pDay)
/* 284:    */       {
/* 285:    */       case 1: 
/* 286:457 */         this.yearType = 9;
/* 287:458 */         break;
/* 288:    */       case 3: 
/* 289:461 */         this.yearType = 13;
/* 290:462 */         break;
/* 291:    */       case 5: 
/* 292:465 */         this.yearType = 3;
/* 293:    */       }
/* 294:469 */     } else if (this.haser) {
/* 295:470 */       switch (this.pDay)
/* 296:    */       {
/* 297:    */       case 1: 
/* 298:473 */         this.yearType = 11;
/* 299:474 */         break;
/* 300:    */       case 3: 
/* 301:477 */         this.yearType = 1;
/* 302:    */       }
/* 303:    */     } else {
/* 304:481 */       switch (this.pDay)
/* 305:    */       {
/* 306:    */       case 0: 
/* 307:484 */         this.yearType = 9;
/* 308:485 */         break;
/* 309:    */       case 5: 
/* 310:488 */         this.yearType = 3;
/* 311:    */       }
/* 312:    */     }
/* 313:491 */     if (this.leap)
/* 314:    */     {
/* 315:493 */       this.nMths = 13;
/* 316:494 */       this.months = new Month[this.nMths];
/* 317:495 */       this.months[0] = new Month(0, "Tishri", 30, this);
/* 318:496 */       if (this.malei) {
/* 319:497 */         this.months[1] = new Month(1, "Heshvan", 30, this);
/* 320:    */       } else {
/* 321:499 */         this.months[1] = new Month(1, "Heshvan", 29, this);
/* 322:    */       }
/* 323:500 */       if (this.haser) {
/* 324:501 */         this.months[2] = new Month(2, "Kislev", 29, this);
/* 325:    */       } else {
/* 326:503 */         this.months[2] = new Month(2, "Kislev", 30, this);
/* 327:    */       }
/* 328:504 */       this.months[3] = new Month(3, "Tebeth", 29, this);
/* 329:505 */       this.months[4] = new Month(4, "Shebat", 30, this);
/* 330:506 */       this.months[5] = new Month(5, "Adar I", 30, this);
/* 331:507 */       this.months[6] = new Month(6, "Adar II", 29, this);
/* 332:508 */       this.months[7] = new Month(7, "Nisan", 30, this);
/* 333:509 */       this.months[8] = new Month(8, "Iyar", 29, this);
/* 334:510 */       this.months[9] = new Month(9, "Sivan", 30, this);
/* 335:511 */       this.months[10] = new Month(10, "Tammuz", 29, this);
/* 336:512 */       this.months[11] = new Month(11, "Ab", 30, this);
/* 337:513 */       this.months[12] = new Month(12, "Elul", 29, this);
/* 338:    */     }
/* 339:    */     else
/* 340:    */     {
/* 341:516 */       this.nMths = 12;
/* 342:517 */       this.months = new Month[this.nMths];
/* 343:518 */       this.months[0] = new Month(0, "Tishri", 30, this);
/* 344:519 */       if (this.malei) {
/* 345:520 */         this.months[1] = new Month(1, "Heshvan", 30, this);
/* 346:    */       } else {
/* 347:522 */         this.months[1] = new Month(1, "Heshvan", 29, this);
/* 348:    */       }
/* 349:523 */       if (this.haser) {
/* 350:524 */         this.months[2] = new Month(2, "Kislev", 29, this);
/* 351:    */       } else {
/* 352:526 */         this.months[2] = new Month(2, "Kislev", 30, this);
/* 353:    */       }
/* 354:527 */       this.months[3] = new Month(3, "Tebeth", 29, this);
/* 355:528 */       this.months[4] = new Month(4, "Shebat", 30, this);
/* 356:529 */       this.months[5] = new Month(5, "Adar", 29, this);
/* 357:530 */       this.months[6] = new Month(6, "Nisan", 30, this);
/* 358:531 */       this.months[7] = new Month(7, "Iyar", 29, this);
/* 359:532 */       this.months[8] = new Month(8, "Sivan", 30, this);
/* 360:533 */       this.months[9] = new Month(9, "Tammuz", 29, this);
/* 361:534 */       this.months[10] = new Month(10, "Ab", 30, this);
/* 362:535 */       this.months[11] = new Month(11, "Elul", 29, this);
/* 363:    */     }
/* 364:537 */     for (int i = 0; i < this.nMths - 1; i++) {
/* 365:538 */       this.months[i].setNext(this.months[(i + 1)]);
/* 366:    */     }
/* 367:    */   }
/* 368:    */   
/* 369:    */   public void connect(Year y)
/* 370:    */   {
/* 371:557 */     int day = this.pDay - 1;
/* 372:558 */     if (day < 0) {
/* 373:559 */       day = 6;
/* 374:    */     }
/* 375:560 */     Day ds = y.getMonth(this.pSolMonth).getDay(this.pSolDate - 1);
/* 376:561 */     for (Day dl = this.months[(6 + 0)].getDay(14); dl.getPrev() != null;)
/* 377:    */     {
/* 378:563 */       day--;
/* 379:563 */       if (day < 0) {
/* 380:564 */         day = 6;
/* 381:    */       }
/* 382:565 */       dl = dl.getPrev();
/* 383:566 */       ds = ds.getPrev();
/* 384:    */     }
/* 385:569 */     for (Day dl = this.months[0].getDay(0); dl != null;)
/* 386:    */     {
/* 387:571 */       day++;
/* 388:571 */       if (day > 6) {
/* 389:572 */         day = 0;
/* 390:    */       }
/* 391:573 */       dl.connect(ds);
/* 392:574 */       dl.setDOW(day);
/* 393:575 */       ds.setDOW(day);
/* 394:576 */       dl = dl.getNext();
/* 395:577 */       ds = ds.getNext();
/* 396:    */     }
/* 397:    */   }
/* 398:    */   
/* 399:    */   public void setHagim(boolean eretzFlag)
/* 400:    */   {
/* 401:584 */     int i = firstParasha[(this.yearType - 1)];
/* 402:585 */     int j = 0;
/* 403:586 */     int y = this.months[0].getYear().getYear();
/* 404:587 */     int eretz = eretzFlag ? 0 : 1;
/* 405:588 */     for (Day dy = this.months[0].getDay(0); dy != null; dy = dy.getNext())
/* 406:    */     {
/* 407:590 */       dy.setHagim(eretzFlag);
/* 408:591 */       if ((dy.getDOW() == 0) && (!dy.isHag())) {
/* 409:592 */         if ((i == 0) || (i != doubleMatrix[eretz][(this.yearType - 1)][j]))
/* 410:    */         {
/* 411:594 */           dy.setParasha(i);
/* 412:595 */           i = (i + 1) % 53;
/* 413:    */         }
/* 414:    */         else
/* 415:    */         {
/* 416:598 */           dy.setDoubleParasha(i);
/* 417:599 */           i = (i + 2) % 53;
/* 418:600 */           j++;
/* 419:    */         }
/* 420:    */       }
/* 421:    */     }
/* 422:    */   }
/* 423:    */   
/* 424:    */   public int getPSolDate()
/* 425:    */   {
/* 426:608 */     return this.pSolDate;
/* 427:    */   }
/* 428:    */   
/* 429:    */   public int getPSolMonth()
/* 430:    */   {
/* 431:614 */     return this.pSolMonth;
/* 432:    */   }
/* 433:    */   
/* 434:    */   public int getYearType()
/* 435:    */   {
/* 436:619 */     return this.yearType;
/* 437:    */   }
/* 438:    */   
/* 439:    */   public int getPDay()
/* 440:    */   {
/* 441:624 */     return this.pDay;
/* 442:    */   }
/* 443:    */   
/* 444:    */   public int getPassoverDay()
/* 445:    */   {
/* 446:630 */     return this.PassoverDay;
/* 447:    */   }
/* 448:    */   
/* 449:    */   public int getPassoverDate()
/* 450:    */   {
/* 451:635 */     return this.PassoverDate;
/* 452:    */   }
/* 453:    */   
/* 454:    */   public int getPassoverMonth()
/* 455:    */   {
/* 456:640 */     return this.PassoverMonth;
/* 457:    */   }
/* 458:    */   
/* 459:    */   public int getPentHebDt()
/* 460:    */   {
/* 461:645 */     return this.PentHebDt;
/* 462:    */   }
/* 463:    */   
/* 464:    */   public boolean getIsHebLeapYr()
/* 465:    */   {
/* 466:651 */     return this.IsHebLeapYr;
/* 467:    */   }
/* 468:    */   
/* 469:    */   public static int getFdub()
/* 470:    */   {
/* 471:659 */     return Fdub;
/* 472:    */   }
/* 473:    */   
/* 474:    */   public static int getFdtub()
/* 475:    */   {
/* 476:664 */     return Fdtub;
/* 477:    */   }
/* 478:    */   
/* 479:    */   public static int getFmub()
/* 480:    */   {
/* 481:669 */     return Fmub;
/* 482:    */   }
/* 483:    */   
/* 484:    */   public static int getLdub()
/* 485:    */   {
/* 486:674 */     return Ldub;
/* 487:    */   }
/* 488:    */   
/* 489:    */   public static int getLdtub()
/* 490:    */   {
/* 491:679 */     return Ldtub;
/* 492:    */   }
/* 493:    */   
/* 494:    */   public static int getLmub()
/* 495:    */   {
/* 496:684 */     return Lmub;
/* 497:    */   }
/* 498:    */   
/* 499:    */   public int getWaveDay()
/* 500:    */   {
/* 501:689 */     return WaveDay;
/* 502:    */   }
/* 503:    */   
/* 504:    */   public int getWaveDate()
/* 505:    */   {
/* 506:694 */     return WaveDate;
/* 507:    */   }
/* 508:    */   
/* 509:    */   public int getWaveHebDt()
/* 510:    */   {
/* 511:699 */     return this.WaveHebDt;
/* 512:    */   }
/* 513:    */   
/* 514:    */   public int getWaveMonth()
/* 515:    */   {
/* 516:704 */     return WaveMonth;
/* 517:    */   }
/* 518:    */   
/* 519:    */   public static int getPentDay()
/* 520:    */   {
/* 521:710 */     return PentDay;
/* 522:    */   }
/* 523:    */   
/* 524:    */   public static int getPentDate()
/* 525:    */   {
/* 526:715 */     return PentDate;
/* 527:    */   }
/* 528:    */   
/* 529:    */   public static int getPentMonth()
/* 530:    */   {
/* 531:720 */     return PentMonth;
/* 532:    */   }
/* 533:    */   
/* 534:723 */   public static String[] parshiot = { "Bereishit", "Noach", "Lech-Lecha", "VaYera", "Haye-Sara", "Toldot", "VeYetse", "VaYishlach", "VaYeshev", "Mikets", "VaYigash", "VaYechi", "Shemot", "VaEra", "Bo", "BeShalach", "Yitro", "Mishpatim", "Teruma", "Tetsave", "Ki-Tisa", "VaYakhel", "Pekudei", "YaYikra", "Tsav", "Shemini", "Tazria", "Metsora", "Acharei-Mot", "Kedoshim", "Emor", "Behar", "BeHukotai", "BaMidbar", "Naso", "BeHaalotecha", "Shelah-Lecha", "Korach", "Hukat", "Balak", "Pinhas", "Matot", "Masei", "Devarim", "VaEtchanan", "Ekev", "Reeh", "Shoftim", "Ki-Tetse", "Ki-Tavo", "Nitsavim", "VeYelech", "Haazinu" };
/* 535:731 */   public static int[][][] doubleMatrix = { { { 21, 26, 28, 31, 41, 50, 0 }, { 41, 50, 0, 0, 0, 0, 0 }, { 21, 26, 28, 31, 41, 50, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 21, 26, 28, 31, 41, 50, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 21, 26, 28, 41, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 21, 26, 28, 41, 0, 0, 0 }, { 50, 0, 0, 0, 0, 0, 0 }, { 21, 26, 28, 31, 41, 0, 0 }, { 41, 50, 0, 0, 0, 0, 0 }, { 21, 26, 28, 31, 41, 50, 0 }, { 41, 50, 0, 0, 0, 0, 0 } }, { { 21, 26, 28, 31, 41, 50, 0 }, { 38, 41, 50, 0, 0, 0, 0 }, { 21, 26, 28, 31, 38, 41, 50 }, { 41, 0, 0, 0, 0, 0, 0 }, { 21, 26, 28, 31, 38, 41, 50 }, { 41, 0, 0, 0, 0, 0, 0 }, { 21, 26, 28, 31, 41, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 21, 26, 28, 31, 41, 0, 0, 0 }, { 50, 0, 0, 0, 0, 0, 0 }, { 21, 26, 28, 31, 41, 0, 0 }, { 41, 50, 0, 0, 0, 0, 0 }, { 21, 26, 28, 31, 41, 50, 0 }, { 38, 41, 50, 0, 0, 0, 0 } } };
/* 536:794 */   public static int[] firstParasha = { 51, 51, 51, 51, 51, 51, 52, 52, 52, 52, 52, 52, 52, 52, 52 };
/* 537:    */   protected boolean malei;
/* 538:    */   protected boolean haser;
/* 539:    */   protected boolean IsHebLeapYr;
/* 540:    */   protected int pSolDate;
/* 541:    */   protected int pSolMonth;
/* 542:    */   protected int pDay;
/* 543:    */   protected int yearType;
/* 544:    */   protected int PassoverDay;
/* 545:    */   protected int PassoverDate;
/* 546:    */   protected int PassoverMonth;
/* 547:    */   protected static int Fdub;
/* 548:    */   protected static int Fmub;
/* 549:    */   protected static int Fdtub;
/* 550:    */   protected static int Ldub;
/* 551:    */   protected static int Lmub;
/* 552:    */   protected static int Ldtub;
/* 553:    */   protected static int WaveDay;
/* 554:    */   protected static int WaveMonth;
/* 555:    */   protected static int WaveDate;
/* 556:    */   protected static int PentDay;
/* 557:    */   protected static int PentMonth;
/* 558:    */   protected static int PentDate;
/* 559:    */   protected int WaveHebDt;
/* 560:    */   protected int PentHebDt;
/* 561:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     LunarYear
 * JD-Core Version:    0.7.1
 */