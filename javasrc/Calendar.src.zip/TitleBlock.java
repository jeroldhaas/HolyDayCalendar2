/*  1:   */ import java.awt.Color;
/*  2:   */ import java.awt.Dimension;
/*  3:   */ import java.awt.Font;
/*  4:   */ import java.awt.FontMetrics;
/*  5:   */ import java.awt.Graphics;
/*  6:   */ 
/*  7:   */ public class TitleBlock
/*  8:   */   extends CalendarBlock
/*  9:   */ {
/* 10:   */   String title;
/* 11:   */   
/* 12:   */   public TitleBlock(String s)
/* 13:   */   {
/* 14:13 */     this.title = s;
/* 15:   */     
/* 16:15 */     this.bgcolor = Color.white;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void paint(Graphics g)
/* 20:   */   {
/* 21:20 */     super.paint(g);
/* 22:   */     
/* 23:   */ 
/* 24:   */ 
/* 25:24 */     this.f = new Font("Arial", 1, 12);
/* 26:25 */     this.fm = getFontMetrics(this.f);
/* 27:   */     
/* 28:   */ 
/* 29:28 */     g.setFont(this.f);
/* 30:29 */     g.setColor(Color.black);
/* 31:30 */     g.drawString(this.title, (int)((getSize().width - this.fm.stringWidth(this.title)) / 2 + 0.5D), (int)((getSize().height / 2 + this.fm.getHeight()) / 2 + 0.5D));
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     TitleBlock
 * JD-Core Version:    0.7.1
 */