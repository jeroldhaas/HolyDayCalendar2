/*   1:    */ import java.awt.Color;
/*   2:    */ 
/*   3:    */ public class Day
/*   4:    */ {
/*   5:    */   int PSab1;
/*   6:    */   int PSab2;
/*   7:    */   int PSab3;
/*   8:    */   int PSab4;
/*   9:    */   int PSab5;
/*  10:    */   int PSab6;
/*  11:    */   int PSab7;
/*  12:    */   int PSabMth1;
/*  13:    */   int PSabMth2;
/*  14:    */   int PSabMth3;
/*  15:    */   int PSabMth4;
/*  16:    */   int PSabMth5;
/*  17:    */   int PSabMth6;
/*  18:    */   int PSabMth7;
/*  19:    */   
/*  20:    */   public void setDoubleParasha(int i) {}
/*  21:    */   
/*  22:    */   public String getName()
/*  23:    */   {
/*  24: 22 */     return this.name;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public Day getPrev()
/*  28:    */   {
/*  29: 27 */     return this.prev;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setPrev(Day d)
/*  33:    */   {
/*  34: 32 */     this.prev = d;
/*  35: 33 */     if ((d != null) && (d.next == null)) {
/*  36: 34 */       d.next = this;
/*  37:    */     }
/*  38:    */   }
/*  39:    */   
/*  40:    */   public Month getMonth()
/*  41:    */   {
/*  42: 39 */     return this.month;
/*  43:    */   }
/*  44:    */   
/*  45:    */   protected void addBgcolor(Color color)
/*  46:    */   {
/*  47: 44 */     if (color == SHABBAT) {
/*  48: 47 */       this.bgcolor = Color.white;
/*  49:    */     }
/*  50: 50 */     if (color == HD) {
/*  51: 51 */       this.bgcolor = HD;
/*  52:    */     } else {
/*  53: 53 */       this.bgcolor = color;
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Color getBgcolor()
/*  58:    */   {
/*  59: 72 */     return this.bgcolor;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Day getOther()
/*  63:    */   {
/*  64: 77 */     return this.other;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Day getNext()
/*  68:    */   {
/*  69: 82 */     return this.next;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setParasha(int i) {}
/*  73:    */   
/*  74:    */   public Day(int dow, int date, Month month)
/*  75:    */   {
/*  76: 92 */     this.bgcolor = CalendarBlock.BLANK;
/*  77: 93 */     this.dow = dow;
/*  78: 94 */     this.date = date;
/*  79: 95 */     this.month = month;
/*  80: 96 */     switch (dow)
/*  81:    */     {
/*  82:    */     case 1: 
/*  83: 99 */       this.name = "Sunday";
/*  84:100 */       break;
/*  85:    */     case 2: 
/*  86:103 */       this.name = "Monday";
/*  87:104 */       break;
/*  88:    */     case 3: 
/*  89:107 */       this.name = "Tuesday";
/*  90:108 */       break;
/*  91:    */     case 4: 
/*  92:111 */       this.name = "Wednesday";
/*  93:112 */       break;
/*  94:    */     case 5: 
/*  95:115 */       this.name = "Thursday";
/*  96:116 */       break;
/*  97:    */     case 6: 
/*  98:119 */       this.name = "Friday";
/*  99:120 */       break;
/* 100:    */     case 0: 
/* 101:123 */       this.name = "Saturday";
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public boolean isHag()
/* 106:    */   {
/* 107:130 */     return this.hagFlag;
/* 108:    */   }
/* 109:    */   
/* 110:    */   protected void addHag(String newHag)
/* 111:    */   {
/* 112:135 */     if (this.hag != null) {
/* 113:136 */       this.hag = (this.hag + ",   " + newHag);
/* 114:    */     } else {
/* 115:138 */       this.hag = newHag;
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   public String getHag()
/* 120:    */   {
/* 121:143 */     return this.hag;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setNext(Day d)
/* 125:    */   {
/* 126:148 */     this.next = d;
/* 127:149 */     if ((d != null) && (d.prev == null)) {
/* 128:150 */       d.prev = this;
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void connect(Day d)
/* 133:    */   {
/* 134:155 */     this.other = d;
/* 135:156 */     if (d != null) {
/* 136:157 */       d.other = this;
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */   public int getDOW()
/* 141:    */   {
/* 142:162 */     return this.dow;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void setDOW(int n)
/* 146:    */   {
/* 147:167 */     this.dow = n;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public int getDate()
/* 151:    */   {
/* 152:172 */     return this.date;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void PentecostSab()
/* 156:    */   {
/* 157:196 */     int PentWaveDate = ((LunarYear)this.month.getYear()).getWaveHebDt();
/* 158:197 */     int PentWaveMonth = 6;
/* 159:    */     
/* 160:    */ 
/* 161:    */ 
/* 162:201 */     boolean HebrewLeapYr = ((LunarYear)this.month.getYear()).getIsHebLeapYr();
/* 163:205 */     if (HebrewLeapYr) {
/* 164:206 */       PentWaveMonth = 7;
/* 165:    */     }
/* 166:214 */     this.PSabMth1 = PentWaveMonth;
/* 167:215 */     this.PSab1 = (PentWaveDate + 6);
/* 168:    */     
/* 169:217 */     this.PSabMth2 = this.PSabMth1;
/* 170:218 */     this.PSab2 = (this.PSab1 + 7);
/* 171:222 */     if (this.PSab2 > 30)
/* 172:    */     {
/* 173:223 */       this.PSab2 -= 30;
/* 174:224 */       this.PSabMth2 += 1;
/* 175:    */     }
/* 176:228 */     this.PSabMth3 = this.PSabMth2;
/* 177:229 */     this.PSab3 = (this.PSab2 + 7);
/* 178:232 */     if (this.PSab3 > 30)
/* 179:    */     {
/* 180:233 */       this.PSab3 -= 30;
/* 181:234 */       this.PSabMth3 += 1;
/* 182:    */     }
/* 183:238 */     this.PSabMth4 = this.PSabMth3;
/* 184:239 */     this.PSab4 = (this.PSab3 + 7);
/* 185:242 */     if (this.PSab4 > 29)
/* 186:    */     {
/* 187:243 */       this.PSab4 -= 29;
/* 188:244 */       this.PSabMth4 += 1;
/* 189:    */     }
/* 190:248 */     this.PSabMth5 = this.PSabMth4;
/* 191:249 */     this.PSab5 = (this.PSab4 + 7);
/* 192:252 */     if (this.PSab5 > 29)
/* 193:    */     {
/* 194:253 */       this.PSab5 -= 29;
/* 195:254 */       this.PSabMth5 += 1;
/* 196:    */     }
/* 197:257 */     this.PSabMth6 = this.PSabMth5;
/* 198:258 */     this.PSab6 = (this.PSab5 + 7);
/* 199:261 */     if (this.PSab6 > 29)
/* 200:    */     {
/* 201:262 */       this.PSab6 -= 29;
/* 202:263 */       this.PSabMth6 += 1;
/* 203:    */     }
/* 204:266 */     this.PSabMth7 = this.PSabMth6;
/* 205:267 */     this.PSab7 = (this.PSab6 + 7);
/* 206:270 */     if (this.PSab7 > 29)
/* 207:    */     {
/* 208:271 */       this.PSab7 -= 29;
/* 209:272 */       this.PSabMth7 += 1;
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   public void PentecostSabChk()
/* 214:    */   {
/* 215:299 */     if ((this.month.getNum() == this.PSabMth1) && (this.date + 1 == this.PSab1))
/* 216:    */     {
/* 217:301 */       addBgcolor(PentCtSab);
/* 218:302 */       this.hagFlag = true;
/* 219:303 */       addHag("Day 7 Toward Pentecost");
/* 220:    */     }
/* 221:309 */     if ((this.month.getNum() == this.PSabMth2) && (this.date + 1 == this.PSab2))
/* 222:    */     {
/* 223:311 */       addBgcolor(PentCtSab);
/* 224:312 */       this.hagFlag = true;
/* 225:313 */       addHag("Day 14 Toward Pentecost");
/* 226:    */     }
/* 227:320 */     if ((this.month.getNum() == this.PSabMth3) && (this.date + 1 == this.PSab3))
/* 228:    */     {
/* 229:323 */       addBgcolor(PentCtSab);
/* 230:324 */       this.hagFlag = true;
/* 231:325 */       addHag("Day 21 Toward Pentecost");
/* 232:    */     }
/* 233:332 */     if ((this.month.getNum() == this.PSabMth4) && (this.date + 1 == this.PSab4))
/* 234:    */     {
/* 235:334 */       addBgcolor(PentCtSab);
/* 236:335 */       this.hagFlag = true;
/* 237:336 */       addHag("Day 28 Toward Pentecost");
/* 238:    */     }
/* 239:342 */     if ((this.month.getNum() == this.PSabMth5) && (this.date + 1 == this.PSab5))
/* 240:    */     {
/* 241:345 */       addBgcolor(PentCtSab);
/* 242:346 */       this.hagFlag = true;
/* 243:347 */       addHag("Day 35 Toward Pentecost");
/* 244:    */     }
/* 245:353 */     if ((this.month.getNum() == this.PSabMth6) && (this.date + 1 == this.PSab6))
/* 246:    */     {
/* 247:356 */       addBgcolor(PentCtSab);
/* 248:357 */       this.hagFlag = true;
/* 249:358 */       addHag("Day 42 Toward Pentecost");
/* 250:    */     }
/* 251:364 */     if ((this.month.getNum() == this.PSabMth7) && (this.date + 1 == this.PSab7))
/* 252:    */     {
/* 253:366 */       addBgcolor(PentCtSab);
/* 254:367 */       this.hagFlag = true;
/* 255:368 */       addHag("Day 49 Toward Pentecost");
/* 256:    */     }
/* 257:    */   }
/* 258:    */   
/* 259:    */   public void setHagim(boolean eretzFlag)
/* 260:    */   {
/* 261:376 */     if ((this.month.getYear() instanceof LunarYear))
/* 262:    */     {
/* 263:378 */       int mth = this.month.getNum();
/* 264:384 */       if ((this.month.getYear().isLeap()) && (mth >= 6)) {
/* 265:385 */         mth--;
/* 266:    */       }
/* 267:396 */       int PDate = ((LunarYear)this.month.getYear()).getPentHebDt();
/* 268:397 */       int WDate = ((LunarYear)this.month.getYear()).getPassoverDay();
/* 269:    */       
/* 270:    */ 
/* 271:400 */       PentecostSab();
/* 272:410 */       if (((this.month.getNum() == 8) || (this.month.getNum() == 9)) && (this.month.getName().equals("Sivan")) && (this.date + 1 == PDate))
/* 273:    */       {
/* 274:411 */         addBgcolor(HD);
/* 275:412 */         this.hagFlag = true;
/* 276:413 */         addHag("Pentecost");
/* 277:    */       }
/* 278:417 */       int CkSpecialYr = this.month.getYear().getYear();
/* 279:423 */       switch (mth)
/* 280:    */       {
/* 281:    */       case 1: 
/* 282:    */       case 2: 
/* 283:    */       case 3: 
/* 284:    */       case 4: 
/* 285:    */       case 5: 
/* 286:    */       default: 
/* 287:    */         break;
/* 288:    */       case 0: 
/* 289:433 */         switch (this.date + 1)
/* 290:    */         {
/* 291:    */         case 1: 
/* 292:436 */           addBgcolor(HD);
/* 293:437 */           this.hagFlag = true;
/* 294:440 */           if (CkSpecialYr == 3757) {
/* 295:441 */             addHag("Feast of Trumpets - birth of Jesus");
/* 296:    */           } else {
/* 297:443 */             addHag("Feast of Trumpets");
/* 298:    */           }
/* 299:448 */           break;
/* 300:    */         case 10: 
/* 301:451 */           addBgcolor(HD);
/* 302:452 */           this.hagFlag = true;
/* 303:453 */           addHag("Day of Atonement");
/* 304:454 */           break;
/* 305:    */         case 15: 
/* 306:    */         case 16: 
/* 307:    */         case 17: 
/* 308:    */         case 18: 
/* 309:    */         case 19: 
/* 310:    */         case 20: 
/* 311:    */         case 21: 
/* 312:463 */           addBgcolor(HD);
/* 313:464 */           this.hagFlag = true;
/* 314:465 */           addHag("Feast of Tabernacles");
/* 315:466 */           break;
/* 316:    */         case 22: 
/* 317:469 */           addBgcolor(HD);
/* 318:470 */           this.hagFlag = true;
/* 319:471 */           addHag("Last Great Day");
/* 320:    */         }
/* 321:474 */         break;
/* 322:    */       case 6: 
/* 323:481 */         if (!this.month.getName().equals("Adar II")) {
/* 324:483 */           switch (this.date + 1)
/* 325:    */           {
/* 326:    */           default: 
/* 327:    */             break;
/* 328:    */           case 13: 
/* 329:489 */             this.hagFlag = true;
/* 330:491 */             if (CkSpecialYr == 3790) {
/* 331:492 */               addHag("Passover observed after sunset by Jesus and apostles.");
/* 332:    */             }
/* 333:    */             break;
/* 334:    */           case 14: 
/* 335:497 */             addBgcolor(HD);
/* 336:498 */             this.hagFlag = true;
/* 337:500 */             if (CkSpecialYr == 3790) {
/* 338:501 */               addHag("Passover - Day of Jesus' crucifixion.");
/* 339:    */             } else {
/* 340:503 */               addHag("Passover");
/* 341:    */             }
/* 342:505 */             break;
/* 343:    */           case 17: 
/* 344:508 */             addBgcolor(HD);
/* 345:509 */             this.hagFlag = true;
/* 346:511 */             if (CkSpecialYr == 3790) {
/* 347:512 */               addHag("Feast of Unleavened Bread-Jesus arose at sunset ending Sabbath.");
/* 348:    */             } else {
/* 349:514 */               addHag("Feast of Unleavened Bread");
/* 350:    */             }
/* 351:517 */             break;
/* 352:    */           case 15: 
/* 353:    */           case 16: 
/* 354:    */           case 18: 
/* 355:    */           case 19: 
/* 356:    */           case 20: 
/* 357:    */           case 21: 
/* 358:526 */             addBgcolor(HD);
/* 359:527 */             this.hagFlag = true;
/* 360:528 */             addHag("Feast of Unleavened Bread");
/* 361:    */           }
/* 362:    */         }
/* 363:529 */         break;
/* 364:    */       case 7: 
/* 365:534 */         if (!this.month.getName().equals("Iyar")) {
/* 366:537 */           switch (this.date + 1)
/* 367:    */           {
/* 368:    */           default: 
/* 369:    */             break;
/* 370:    */           case 13: 
/* 371:543 */             this.hagFlag = true;
/* 372:545 */             if (CkSpecialYr == 3790) {
/* 373:546 */               addHag("Passover observed after sunset by Jesus and apostles.");
/* 374:    */             }
/* 375:    */             break;
/* 376:    */           case 14: 
/* 377:552 */             addBgcolor(HD);
/* 378:553 */             this.hagFlag = true;
/* 379:555 */             if (CkSpecialYr == 3790) {
/* 380:556 */               addHag("Passover - Day of Jesus' crucifixion.");
/* 381:    */             } else {
/* 382:558 */               addHag("Passover");
/* 383:    */             }
/* 384:562 */             break;
/* 385:    */           case 17: 
/* 386:565 */             addBgcolor(HD);
/* 387:566 */             this.hagFlag = true;
/* 388:568 */             if (CkSpecialYr == 3790) {
/* 389:569 */               addHag("Feast of Unleavened Bread-Jesus arose at sunset ending Sabbath.");
/* 390:    */             } else {
/* 391:571 */               addHag("Feast of Unleavened Bread");
/* 392:    */             }
/* 393:573 */             break;
/* 394:    */           case 15: 
/* 395:    */           case 16: 
/* 396:    */           case 18: 
/* 397:    */           case 19: 
/* 398:    */           case 20: 
/* 399:    */           case 21: 
/* 400:581 */             addBgcolor(HD);
/* 401:582 */             this.hagFlag = true;
/* 402:583 */             addHag("Feast of Unleavened Bread");
/* 403:    */           }
/* 404:    */         }
/* 405:    */         break;
/* 406:    */       }
/* 407:597 */       PentecostSabChk();
/* 408:    */     }
/* 409:    */   }
/* 410:    */   
/* 411:    */   public String getDayName(int DNum)
/* 412:    */   {
/* 413:    */     String s;
/* 414:620 */     switch (DNum)
/* 415:    */     {
/* 416:    */     case 0: 
/* 417:623 */       s = "Sunday";
/* 418:624 */       break;
/* 419:    */     case 1: 
/* 420:627 */       s = "Monday";
/* 421:    */       
/* 422:629 */       break;
/* 423:    */     case 2: 
/* 424:632 */       s = "Tuesday";
/* 425:    */       
/* 426:634 */       break;
/* 427:    */     case 3: 
/* 428:637 */       s = "Wednesday";
/* 429:    */       
/* 430:639 */       break;
/* 431:    */     case 4: 
/* 432:642 */       s = "Thursday";
/* 433:    */       
/* 434:644 */       break;
/* 435:    */     case 5: 
/* 436:647 */       s = "Friday";
/* 437:    */       
/* 438:649 */       break;
/* 439:    */     case 6: 
/* 440:652 */       s = "Saturday";
/* 441:    */       
/* 442:654 */       break;
/* 443:    */     default: 
/* 444:657 */       s = "DAY IS INCORRECT";
/* 445:    */     }
/* 446:662 */     return s;
/* 447:    */   }
/* 448:    */   
/* 449:    */   public String getMthName(int MNum)
/* 450:    */   {
/* 451:    */     String m;
/* 452:673 */     switch (MNum)
/* 453:    */     {
/* 454:    */     case 0: 
/* 455:676 */       m = " January";
/* 456:    */       
/* 457:678 */       break;
/* 458:    */     case 1: 
/* 459:681 */       m = " February";
/* 460:    */       
/* 461:683 */       break;
/* 462:    */     case 2: 
/* 463:686 */       m = " March";
/* 464:    */       
/* 465:688 */       break;
/* 466:    */     case 3: 
/* 467:691 */       m = " April";
/* 468:    */       
/* 469:693 */       break;
/* 470:    */     case 4: 
/* 471:696 */       m = " May";
/* 472:    */       
/* 473:698 */       break;
/* 474:    */     case 5: 
/* 475:701 */       m = " June";
/* 476:    */       
/* 477:703 */       break;
/* 478:    */     case 6: 
/* 479:706 */       m = " July";
/* 480:    */       
/* 481:708 */       break;
/* 482:    */     case 7: 
/* 483:710 */       m = " August";
/* 484:    */       
/* 485:712 */       break;
/* 486:    */     case 8: 
/* 487:715 */       m = " September";
/* 488:    */       
/* 489:717 */       break;
/* 490:    */     case 9: 
/* 491:720 */       m = " October";
/* 492:    */       
/* 493:722 */       break;
/* 494:    */     case 10: 
/* 495:725 */       m = " November";
/* 496:    */       
/* 497:727 */       break;
/* 498:    */     case 11: 
/* 499:730 */       m = " December";
/* 500:    */       
/* 501:732 */       break;
/* 502:    */     default: 
/* 503:736 */       m = " MONTH IS INCORRECT";
/* 504:    */     }
/* 505:740 */     return m;
/* 506:    */   }
/* 507:    */   
/* 508:743 */   protected static final Color SHABBAT = new Color(216, 216, 255);
/* 509:745 */   protected static final Color PentCtSab = new Color(216, 216, 255);
/* 510:748 */   protected static final Color HD = new Color(208, 208, 208);
/* 511:752 */   protected static final Color MOED = new Color(255, 255, 208);
/* 512:753 */   protected static final Color HAG = new Color(255, 255, 128);
/* 513:754 */   protected static final Color TZOM = new Color(208, 208, 208);
/* 514:    */   protected int date;
/* 515:    */   protected String name;
/* 516:    */   protected int dow;
/* 517:    */   protected Day next;
/* 518:    */   protected Day prev;
/* 519:    */   protected Day other;
/* 520:    */   protected Month month;
/* 521:    */   protected String hag;
/* 522:    */   protected boolean hagFlag;
/* 523:    */   protected Color bgcolor;
/* 524:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     Day
 * JD-Core Version:    0.7.1
 */