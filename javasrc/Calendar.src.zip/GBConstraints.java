/*  1:   */ import java.awt.GridBagConstraints;
/*  2:   */ 
/*  3:   */ public class GBConstraints
/*  4:   */   extends GridBagConstraints
/*  5:   */ {
/*  6:   */   public GridBagConstraints setConstraints(int gx, int gy, int gw, int gh, int wx, int wy)
/*  7:   */   {
/*  8:10 */     this.gridx = gx;
/*  9:11 */     this.gridy = gy;
/* 10:12 */     this.gridwidth = gw;
/* 11:13 */     this.gridheight = gh;
/* 12:14 */     this.weightx = wx;
/* 13:15 */     this.weighty = wy;
/* 14:16 */     return this;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public GridBagConstraints setConstraints(int gx, int gy, int gw, int gh, int wx, int wy, int f, int anc)
/* 18:   */   {
/* 19:22 */     this.gridx = gx;
/* 20:23 */     this.gridy = gy;
/* 21:24 */     this.gridwidth = gw;
/* 22:25 */     this.gridheight = gh;
/* 23:26 */     this.weightx = wx;
/* 24:27 */     this.weighty = wy;
/* 25:28 */     this.fill = f;
/* 26:29 */     this.anchor = anc;
/* 27:30 */     return this;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public GridBagConstraints setConstraints(int gx, int gy, int gw, int gh, int wx, int wy, int f, int anc, int ipx, int ipy)
/* 31:   */   {
/* 32:36 */     this.gridx = gx;
/* 33:37 */     this.gridy = gy;
/* 34:38 */     this.gridwidth = gw;
/* 35:39 */     this.gridheight = gh;
/* 36:40 */     this.weightx = wx;
/* 37:41 */     this.weighty = wy;
/* 38:42 */     this.fill = f;
/* 39:43 */     this.anchor = anc;
/* 40:44 */     this.ipadx = ipx;
/* 41:45 */     this.ipady = ipy;
/* 42:46 */     return this;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public GBConstraints() {}
/* 46:   */   
/* 47:   */   public GBConstraints(int gx, int gy, int gw, int gh, int wx, int wy)
/* 48:   */   {
/* 49:55 */     setConstraints(gx, gy, gw, gh, wx, wy);
/* 50:   */   }
/* 51:   */   
/* 52:   */   public GBConstraints(int gx, int gy, int gw, int gh, int wx, int wy, int f, int anc)
/* 53:   */   {
/* 54:61 */     setConstraints(gx, gy, gw, gh, wx, wy, f, anc);
/* 55:   */   }
/* 56:   */   
/* 57:   */   public GBConstraints(int gx, int gy, int gw, int gh, int wx, int wy, int f, int anc, int ipx, int ipy)
/* 58:   */   {
/* 59:67 */     setConstraints(gx, gy, gw, gh, wx, wy, f, anc, ipx, ipy);
/* 60:   */   }
/* 61:   */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     GBConstraints
 * JD-Core Version:    0.7.1
 */