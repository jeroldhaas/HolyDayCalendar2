/*   1:    */ import javax.swing.BoxLayout;
/*   2:    */ import javax.swing.JFrame;
/*   3:    */ import javax.swing.JLabel;
/*   4:    */ import javax.swing.JPanel;
/*   5:    */ 
/*   6:    */ public class PostDays
/*   7:    */ {
/*   8:    */   protected static JPanel TrbShoot;
/*   9:    */   JFrame TrbFrame;
/*  10:    */   protected static JLabel TrbText;
/*  11:    */   String mtish;
/*  12:    */   protected static boolean NoMoreCheckingflag;
/*  13:    */   private static boolean HebLeapYearPlusOne;
/*  14:    */   private static int NextHebYearCycle;
/*  15:    */   protected static boolean HebLeapYearOneBack;
/*  16:    */   private static int NextHebYearCycleOneBack;
/*  17:    */   
/*  18:    */   public void troubleshooting()
/*  19:    */   {
/*  20: 40 */     this.TrbFrame = new JFrame("TROUBLESHOOTING PANEL");
/*  21:    */     
/*  22:    */ 
/*  23: 43 */     this.TrbFrame.setSize(800, 1200);
/*  24:    */     
/*  25: 45 */     this.TrbFrame.setDefaultCloseOperation(1);
/*  26: 46 */     TrbShoot = new JPanel();
/*  27:    */     
/*  28:    */ 
/*  29: 49 */     TrbShoot.setLayout(new BoxLayout(TrbShoot, 1));
/*  30: 50 */     TrbShoot.setSize(800, 1200);
/*  31:    */     
/*  32:    */ 
/*  33: 53 */     this.TrbFrame.setContentPane(TrbShoot);
/*  34: 54 */     TrbShoot.setOpaque(true);
/*  35:    */     
/*  36:    */ 
/*  37:    */ 
/*  38: 58 */     TrbText = new JLabel("TROUBLESHOOTING PANEL", 0);
/*  39:    */     
/*  40: 60 */     TrbShoot.add(TrbText);
/*  41:    */     
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53: 73 */     TrbText = new JLabel("   ");
/*  54: 74 */     TrbShoot.add(TrbText);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static int PostPoningDays(int NextHebYr)
/*  58:    */   {
/*  59: 99 */     int daysToAdd = 0;
/*  60:100 */     NoMoreCheckingflag = false;
/*  61:    */     
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:111 */     long HebEpochRD = -1373427L;
/*  72:    */     
/*  73:113 */     long monthsThatElapsed = (235 * NextHebYr - 234) / 19;
/*  74:    */     
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:118 */     long HebrewDays = monthsThatElapsed * 29L;
/*  79:119 */     long HebrewParts = monthsThatElapsed * 13753L;
/*  80:    */     
/*  81:    */ 
/*  82:122 */     long HebrewTimeAdj = HebrewParts + 5604L;
/*  83:    */     
/*  84:    */ 
/*  85:    */ 
/*  86:126 */     long ConvertPartsDays = HebrewTimeAdj / 25920L;
/*  87:    */     
/*  88:128 */     long ConvertPartsRem = HebrewTimeAdj % 25920L;
/*  89:    */     
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:135 */     int MoladTishriHrs = 0;
/*  96:136 */     int MoladTishriPts = 0;
/*  97:139 */     if (ConvertPartsRem != 0L)
/*  98:    */     {
/*  99:140 */       MoladTishriHrs = (int)(ConvertPartsRem / 1080L);
/* 100:141 */       MoladTishriPts = (int)(ConvertPartsRem % 1080L);
/* 101:    */     }
/* 102:154 */     long MTempDOW = (HebrewDays + ConvertPartsDays) % 7L;
/* 103:155 */     int molDOW = (int)MTempDOW;
/* 104:    */     
/* 105:    */ 
/* 106:158 */     int MoladDayOfWeek = 0;
/* 107:161 */     switch (molDOW)
/* 108:    */     {
/* 109:    */     case 0: 
/* 110:164 */       MoladDayOfWeek = 1;
/* 111:165 */       break;
/* 112:    */     case 1: 
/* 113:168 */       MoladDayOfWeek = 2;
/* 114:169 */       break;
/* 115:    */     case 2: 
/* 116:172 */       MoladDayOfWeek = 3;
/* 117:173 */       break;
/* 118:    */     case 3: 
/* 119:176 */       MoladDayOfWeek = 4;
/* 120:177 */       break;
/* 121:    */     case 4: 
/* 122:180 */       MoladDayOfWeek = 5;
/* 123:181 */       break;
/* 124:    */     case 5: 
/* 125:184 */       MoladDayOfWeek = 6;
/* 126:185 */       break;
/* 127:    */     case 6: 
/* 128:188 */       MoladDayOfWeek = 0;
/* 129:    */     }
/* 130:195 */     HebLeapYearPlusOne = false;
/* 131:    */     
/* 132:197 */     HebLeapYearOneBack = false;
/* 133:    */     
/* 134:199 */     NextHebYearCycle = 0;
/* 135:200 */     NextHebYearCycleOneBack = 0;
/* 136:    */     
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:205 */     NextHebYearCycle = NextHebYr % 19;
/* 141:211 */     if (NextHebYearCycle == 0) {
/* 142:212 */       NextHebYearCycle = 19;
/* 143:    */     }
/* 144:215 */     if ((NextHebYearCycle == 3) || (NextHebYearCycle == 6) || (NextHebYearCycle == 8) || (NextHebYearCycle == 11) || (NextHebYearCycle == 14) || (NextHebYearCycle == 17) || (NextHebYearCycle == 19)) {
/* 145:218 */       HebLeapYearPlusOne = true;
/* 146:    */     }
/* 147:224 */     NextHebYearCycleOneBack = (NextHebYr - 1) % 19;
/* 148:226 */     if (NextHebYearCycleOneBack == 0) {
/* 149:227 */       NextHebYearCycleOneBack = 19;
/* 150:    */     }
/* 151:229 */     if ((NextHebYearCycleOneBack == 3) || (NextHebYearCycleOneBack == 6) || (NextHebYearCycleOneBack == 8) || (NextHebYearCycleOneBack == 11) || (NextHebYearCycleOneBack == 14) || (NextHebYearCycleOneBack == 17) || (NextHebYearCycleOneBack == 19)) {
/* 152:232 */       HebLeapYearOneBack = true;
/* 153:    */     }
/* 154:251 */     if (((MoladDayOfWeek == 0) || (MoladDayOfWeek == 3) || (MoladDayOfWeek == 5)) && (MoladTishriHrs < 18)) {
/* 155:254 */       daysToAdd = 1;
/* 156:    */     }
/* 157:276 */     int MoladDayOfWeekRule2 = 0;
/* 158:279 */     if (MoladTishriHrs >= 18)
/* 159:    */     {
/* 160:284 */       MoladDayOfWeekRule2 = 1;
/* 161:287 */       if (MoladDayOfWeek == 1) {
/* 162:287 */         NoMoreCheckingflag = true;
/* 163:    */       }
/* 164:    */     }
/* 165:343 */     if ((!HebLeapYearPlusOne) && (MoladDayOfWeek == 2) && (((MoladTishriHrs == 9) && (MoladTishriPts >= 204)) || (MoladTishriHrs > 9))) {
/* 166:347 */       daysToAdd += 1;
/* 167:    */     }
/* 168:360 */     if ((!HebLeapYearPlusOne) && (MoladDayOfWeek == 1) && (((MoladTishriHrs == 15) && (MoladTishriPts >= 589)) || ((MoladTishriHrs > 15) && (HebLeapYearOneBack == true)))) {
/* 169:363 */       if (!NoMoreCheckingflag) {
/* 170:363 */         daysToAdd += 1;
/* 171:    */       }
/* 172:    */     }
/* 173:387 */     int MoladCompare = 0;
/* 174:390 */     if ((daysToAdd < 2) && (!NoMoreCheckingflag))
/* 175:    */     {
/* 176:392 */       MoladCompare = MoladDayOfWeek + daysToAdd + MoladDayOfWeekRule2;
/* 177:398 */       if ((MoladCompare == 7) || (MoladCompare == 3) || (MoladCompare == 5)) {
/* 178:401 */         daysToAdd += 1;
/* 179:    */       }
/* 180:    */     }
/* 181:413 */     if (daysToAdd > 2) {
/* 182:414 */       daysToAdd = 2;
/* 183:    */     }
/* 184:418 */     return daysToAdd;
/* 185:    */   }
/* 186:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     PostDays
 * JD-Core Version:    0.7.1
 */