/*  1:   */ import java.io.PrintStream;
/*  2:   */ 
/*  3:   */ public class Month
/*  4:   */ {
/*  5:   */   protected int num;
/*  6:   */   protected String name;
/*  7:   */   protected int nDays;
/*  8:   */   protected Day[] days;
/*  9:   */   protected Year year;
/* 10:   */   protected Month next;
/* 11:   */   protected Month prev;
/* 12:   */   
/* 13:   */   public String getName()
/* 14:   */   {
/* 15:10 */     return this.name;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public Month getPrev()
/* 19:   */   {
/* 20:15 */     return this.prev;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void setPrev(Month m)
/* 24:   */   {
/* 25:20 */     this.prev = m;
/* 26:21 */     if ((m != null) && (m.next == null)) {
/* 27:22 */       m.next = this;
/* 28:   */     }
/* 29:23 */     this.days[0].setPrev(m.getDay(this.nDays - 1));
/* 30:   */   }
/* 31:   */   
/* 32:   */   public Month(int num, String name)
/* 33:   */   {
/* 34:28 */     this.num = num;
/* 35:29 */     this.name = name;
/* 36:30 */     this.nDays = 0;
/* 37:31 */     this.days = null;
/* 38:32 */     this.year = null;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Month(int num, String name, int nDays, Year year)
/* 42:   */   {
/* 43:37 */     this(num, name);
/* 44:38 */     this.nDays = nDays;
/* 45:39 */     this.days = new Day[nDays];
/* 46:40 */     this.year = year;
/* 47:41 */     for (int i = 0; i < nDays; i++)
/* 48:   */     {
/* 49:43 */       this.days[i] = new Day(0, i, this);
/* 50:44 */       if (i > 0) {
/* 51:45 */         this.days[i].setPrev(this.days[(i - 1)]);
/* 52:   */       }
/* 53:   */     }
/* 54:   */   }
/* 55:   */   
/* 56:   */   public Year getYear()
/* 57:   */   {
/* 58:52 */     return this.year;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public Month getNext()
/* 62:   */   {
/* 63:57 */     return this.next;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public void setNext(Month m)
/* 67:   */   {
/* 68:62 */     this.next = m;
/* 69:63 */     if ((m != null) && (m.prev == null)) {
/* 70:64 */       m.prev = this;
/* 71:   */     }
/* 72:65 */     this.days[(this.nDays - 1)].setNext(m.getDay(0));
/* 73:   */   }
/* 74:   */   
/* 75:   */   public Day getDay(int n)
/* 76:   */   {
/* 77:   */     try
/* 78:   */     {
/* 79:72 */       return this.days[n];
/* 80:   */     }
/* 81:   */     catch (ArrayIndexOutOfBoundsException e)
/* 82:   */     {
/* 83:76 */       System.out.println("Month.getDay(int) index out of bounds n=" + Integer.toString(n));
/* 84:77 */       System.out.println("Month: " + this.name + ", Max Days: " + Integer.toString(this.nDays));
/* 85:78 */       e.printStackTrace();
/* 86:   */     }
/* 87:79 */     return null;
/* 88:   */   }
/* 89:   */   
/* 90:   */   public int getNum()
/* 91:   */   {
/* 92:85 */     return this.num;
/* 93:   */   }
/* 94:   */   
/* 95:   */   public int getNDays()
/* 96:   */   {
/* 97:90 */     return this.nDays;
/* 98:   */   }
/* 99:   */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     Month
 * JD-Core Version:    0.7.1
 */