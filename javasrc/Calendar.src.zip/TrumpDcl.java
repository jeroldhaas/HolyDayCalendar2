/*   1:    */ import java.awt.BorderLayout;
/*   2:    */ import java.awt.Color;
/*   3:    */ import java.awt.Dimension;
/*   4:    */ import java.awt.Font;
/*   5:    */ import java.awt.GridBagConstraints;
/*   6:    */ import java.awt.GridBagLayout;
/*   7:    */ import java.awt.Insets;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.awt.event.ActionListener;
/*  10:    */ import java.awt.event.WindowEvent;
/*  11:    */ import java.awt.event.WindowListener;
/*  12:    */ import javax.swing.BoxLayout;
/*  13:    */ import javax.swing.JButton;
/*  14:    */ import javax.swing.JFrame;
/*  15:    */ import javax.swing.JLabel;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import javax.swing.JScrollPane;
/*  18:    */ import javax.swing.JTextArea;
/*  19:    */ 
/*  20:    */ public class TrumpDcl
/*  21:    */   extends JFrame
/*  22:    */   implements ActionListener, WindowListener
/*  23:    */ {
/*  24:    */   JFrame tframe;
/*  25:    */   JPanel contntPane;
/*  26:    */   JPanel scrollArea;
/*  27:    */   JPanel buttonBottom;
/*  28:    */   JLabel scrollTxt;
/*  29:    */   JLabel PSTTitle;
/*  30:    */   JLabel PstText;
/*  31:    */   String PostOutput;
/*  32:    */   String TempMthHold;
/*  33:    */   String DayName1;
/*  34:    */   String MthName1;
/*  35:    */   String DayName2;
/*  36:    */   String MthName2;
/*  37:    */   String TrumpetsDOW;
/*  38:    */   JTextArea tArea;
/*  39:    */   JButton CLSINGButton;
/*  40:    */   JButton PrintButton;
/*  41:    */   GridBagLayout gridbag;
/*  42:    */   GridBagConstraints c;
/*  43:    */   protected static String prtLocFlag;
/*  44:    */   static boolean HDWinADBCflag;
/*  45:    */   
/*  46:    */   public TrumpDcl(int TSolarYear, String TAdBc)
/*  47:    */   {
/*  48: 35 */     this.tframe = new JFrame("Trumpets Declaration");
/*  49:    */     
/*  50: 37 */     this.tframe.addWindowListener(this);
/*  51:    */     
/*  52: 39 */     this.tframe.setSize(400, 300);
/*  53:    */     
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57: 44 */     this.tframe.setDefaultCloseOperation(2);
/*  58:    */     
/*  59: 46 */     this.contntPane = new JPanel();
/*  60: 47 */     this.contntPane.setOpaque(true);
/*  61: 48 */     this.contntPane.setBackground(Color.white);
/*  62: 49 */     this.contntPane.setSize(400, 300);
/*  63:    */     
/*  64: 51 */     this.contntPane.setLayout(new BorderLayout(5, 7));
/*  65:    */     
/*  66: 53 */     this.tframe.setContentPane(this.contntPane);
/*  67:    */     
/*  68:    */ 
/*  69:    */ 
/*  70: 57 */     int YearOfMolad = HDWin.getPosYearInput();
/*  71:    */     
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76: 63 */     HDWinADBCflag = HDWin.getADBCflag();
/*  77:    */     
/*  78: 65 */     String ADBC = "AD";
/*  79: 67 */     if (HDWinADBCflag == true) {
/*  80: 68 */       ADBC = "AD";
/*  81:    */     } else {
/*  82: 70 */       ADBC = "BC";
/*  83:    */     }
/*  84: 72 */     String TrumpYearType = "Gregorian";
/*  85: 74 */     if ((YearOfMolad >= 1583) && (HDWinADBCflag)) {
/*  86: 75 */       TrumpYearType = "Gregorian";
/*  87: 77 */     } else if (YearOfMolad < 1582) {
/*  88: 78 */       TrumpYearType = "Julian";
/*  89: 80 */     } else if (YearOfMolad == 1582) {
/*  90: 81 */       TrumpYearType = "Julian/Gregorian";
/*  91:    */     }
/*  92: 85 */     String ADBCplus1 = ADBC;
/*  93:    */     
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97: 90 */     this.PSTTitle = new JLabel("Trumpets Declaration for " + YearOfMolad + " " + ADBC + " (" + TrumpYearType + ") ", 0);
/*  98: 91 */     this.PSTTitle.setFont(new Font("Arial", 1, 14));
/*  99:    */     
/* 100: 93 */     this.PSTTitle.setPreferredSize(new Dimension(400, 25));
/* 101: 94 */     this.PSTTitle.setMinimumSize(new Dimension(400, 25));
/* 102:    */     
/* 103:    */ 
/* 104:    */ 
/* 105: 98 */     this.contntPane.add(this.PSTTitle, "North");
/* 106:    */     
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:108 */     this.scrollArea = new JPanel();
/* 116:109 */     this.scrollArea.setOpaque(true);
/* 117:110 */     this.scrollArea.setBackground(Color.white);
/* 118:    */     
/* 119:    */ 
/* 120:113 */     this.scrollArea.setLayout(new BoxLayout(this.scrollArea, 1));
/* 121:    */     
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:118 */     this.buttonBottom = new JPanel();
/* 126:119 */     this.buttonBottom.setOpaque(true);
/* 127:120 */     this.buttonBottom.setBackground(Color.white);
/* 128:    */     
/* 129:    */ 
/* 130:    */ 
/* 131:124 */     this.gridbag = new GridBagLayout();
/* 132:125 */     this.c = new GridBagConstraints();
/* 133:    */     
/* 134:127 */     this.buttonBottom.setLayout(this.gridbag);
/* 135:    */     
/* 136:    */ 
/* 137:130 */     this.c.gridx = 1;
/* 138:131 */     this.c.gridy = 0;
/* 139:132 */     this.c.gridwidth = 1;
/* 140:    */     
/* 141:134 */     this.c.anchor = 10;
/* 142:135 */     this.c.gridheight = 1;
/* 143:    */     
/* 144:137 */     this.c.weightx = 1.0D;
/* 145:138 */     this.c.weighty = 1.0D;
/* 146:    */     
/* 147:140 */     this.c.insets = new Insets(3, 0, 3, 0);
/* 148:    */     
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:150 */     this.DayName1 = getDayName(HDWin.getmTishDOW6PM());
/* 158:151 */     this.MthName1 = getMthName(HDWin.getmTishMth6PM());
/* 159:    */     
/* 160:153 */     int Date1 = HDWin.getmTishDay6PM();
/* 161:    */     
/* 162:155 */     int Thours = HDWin.getmTishHrs6PM();
/* 163:156 */     int Parts = HDWin.getmTishPts6PM();
/* 164:    */     
/* 165:    */ 
/* 166:    */ 
/* 167:160 */     this.TrumpetsDOW = getDayName(HDWin.getTish1DOW());
/* 168:    */     
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:165 */     this.PostOutput = " ";
/* 173:168 */     if (HDWin.getPostRule1() == true) {
/* 174:169 */       this.PostOutput += "1";
/* 175:    */     }
/* 176:171 */     if (HDWin.getPostRule2() == true) {
/* 177:173 */       if (HDWin.getPostRule1() == true) {
/* 178:174 */         this.PostOutput += " and 2";
/* 179:    */       } else {
/* 180:175 */         this.PostOutput = "2";
/* 181:    */       }
/* 182:    */     }
/* 183:179 */     if (HDWin.getPostRule3() == true) {
/* 184:181 */       if ((HDWin.getPostRule1() == true) || (HDWin.getPostRule2() == true)) {
/* 185:182 */         this.PostOutput += " and 3";
/* 186:    */       } else {
/* 187:183 */         this.PostOutput = "3";
/* 188:    */       }
/* 189:    */     }
/* 190:187 */     if (HDWin.getPostRule4() == true) {
/* 191:190 */       if ((HDWin.getPostRule1() == true) || (HDWin.getPostRule2() == true) || (HDWin.getPostRule3() == true)) {
/* 192:191 */         this.PostOutput += " and 4";
/* 193:    */       } else {
/* 194:192 */         this.PostOutput = "4";
/* 195:    */       }
/* 196:    */     }
/* 197:196 */     if (this.PostOutput == " ") {
/* 198:197 */       this.PostOutput += "NONE";
/* 199:    */     }
/* 200:201 */     this.DayName2 = getDayName(HDWin.getTish1DOW());
/* 201:202 */     this.MthName2 = getMthName(HDWin.getTish1Mth());
/* 202:203 */     int Date2 = HDWin.getTish1Day();
/* 203:    */     
/* 204:    */ 
/* 205:206 */     int civilyear = HDWin.getHebYrTish1();
/* 206:207 */     int calyear = civilyear - 1;
/* 207:    */     
/* 208:    */ 
/* 209:    */ 
/* 210:211 */     int tyearplus1 = 0;
/* 211:216 */     if (ADBC == "AD") {
/* 212:217 */       tyearplus1 = YearOfMolad + 1;
/* 213:    */     } else {
/* 214:219 */       tyearplus1 = YearOfMolad - 1;
/* 215:    */     }
/* 216:224 */     if (tyearplus1 == 0)
/* 217:    */     {
/* 218:225 */       tyearplus1 = 1;
/* 219:226 */       ADBCplus1 = "AD";
/* 220:    */     }
/* 221:231 */     int yearcycle = HDWin.getHebCycle();
/* 222:    */     
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:239 */     int YearDaycount = HDWin.getHebYearDaycount();
/* 230:240 */     String dayct = "  ";
/* 231:242 */     if (((YearDaycount >= 353) && (YearDaycount <= 355)) || ((YearDaycount >= 383) && (YearDaycount <= 385))) {
/* 232:244 */       dayct = String.valueOf(YearDaycount);
/* 233:    */     } else {
/* 234:246 */       dayct = " *Error in Year Length:" + String.valueOf(YearDaycount);
/* 235:    */     }
/* 236:255 */     this.tArea = new JTextArea("\nThe Molad of Tishri occurs on:\n" + this.DayName1 + ", " + this.MthName1 + " " + Date1 + ", " + YearOfMolad + " " + ADBC + ", at " + Thours + " hours and " + Parts + " parts\n\n" + "The postponement rule(s) used to declare Feast of Trumpets:\nRule(s) " + this.PostOutput + "\n\nThe declaration of the Feast of Trumpets is therefore:\n" + this.DayName2 + ", " + this.MthName2 + " " + Date2 + ", " + YearOfMolad + " " + ADBC + "\n\nTrumpets " + YearOfMolad + " " + ADBC + " ends civil year " + calyear + " and begins civil year " + civilyear + ".\n\nCivil year " + civilyear + " runs from Trumpets " + YearOfMolad + " " + ADBC + " to Trumpets " + tyearplus1 + " " + ADBCplus1 + ".\nIt is year " + yearcycle + " of the 19-year lunar cycle and has " + dayct + " days.\n");
/* 237:    */     
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:264 */     this.tArea.setEditable(false);
/* 246:    */     
/* 247:266 */     this.tArea.setLineWrap(true);
/* 248:267 */     this.tArea.setWrapStyleWord(true);
/* 249:268 */     this.tArea.setFont(new Font("Arial", 0, 12));
/* 250:    */     
/* 251:270 */     this.tArea.setAlignmentX(0.5F);
/* 252:271 */     this.tArea.setMargin(new Insets(0, 3, 0, 3));
/* 253:    */     
/* 254:    */ 
/* 255:274 */     JScrollPane scrollPane = new JScrollPane(this.tArea);
/* 256:275 */     scrollPane.setSize(new Dimension(400, 300));
/* 257:    */     
/* 258:    */ 
/* 259:278 */     scrollPane.setVerticalScrollBarPolicy(20);
/* 260:279 */     scrollPane.setHorizontalScrollBarPolicy(30);
/* 261:    */     
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:    */ 
/* 269:    */ 
/* 270:    */ 
/* 271:290 */     this.scrollArea.setAlignmentX(0.5F);
/* 272:291 */     this.scrollArea.add(scrollPane);
/* 273:    */     
/* 274:293 */     this.contntPane.add(this.scrollArea, "Center");
/* 275:    */     
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:    */ 
/* 283:    */ 
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */ 
/* 293:    */ 
/* 294:    */ 
/* 295:    */ 
/* 296:    */ 
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:    */ 
/* 303:    */ 
/* 304:    */ 
/* 305:324 */     this.PrintButton = new JButton("Print");
/* 306:325 */     this.PrintButton.addActionListener(this);
/* 307:    */     
/* 308:327 */     this.PrintButton.setPreferredSize(new Dimension(100, 20));
/* 309:328 */     this.PrintButton.setMinimumSize(new Dimension(100, 20));
/* 310:329 */     this.PrintButton.setFont(new Font("Arial", 1, 12));
/* 311:330 */     this.PrintButton.setMargin(new Insets(1, 0, 1, 0));
/* 312:    */     
/* 313:    */ 
/* 314:333 */     this.buttonBottom.add(this.PrintButton, this.c);
/* 315:    */     
/* 316:    */ 
/* 317:336 */     this.c.gridx = 1;
/* 318:337 */     this.c.gridy = 1;
/* 319:    */     
/* 320:    */ 
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:    */ 
/* 325:    */ 
/* 326:    */ 
/* 327:    */ 
/* 328:    */ 
/* 329:348 */     this.CLSINGButton = new JButton("Close");
/* 330:349 */     this.CLSINGButton.addActionListener(this);
/* 331:    */     
/* 332:351 */     this.CLSINGButton.setPreferredSize(new Dimension(150, 20));
/* 333:352 */     this.CLSINGButton.setMinimumSize(new Dimension(150, 20));
/* 334:353 */     this.CLSINGButton.setFont(new Font("Arial", 1, 12));
/* 335:354 */     this.CLSINGButton.setMargin(new Insets(1, 0, 1, 0));
/* 336:    */     
/* 337:    */ 
/* 338:357 */     this.buttonBottom.add(this.CLSINGButton, this.c);
/* 339:    */     
/* 340:    */ 
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:363 */     this.contntPane.add(this.buttonBottom, "South");
/* 345:    */     
/* 346:365 */     addWindowListener(this);
/* 347:    */     
/* 348:367 */     this.tframe.pack();
/* 349:368 */     this.tframe.setVisible(true);
/* 350:    */   }
/* 351:    */   
/* 352:    */   public String getDayName(int DNum)
/* 353:    */   {
/* 354:    */     String s;
/* 355:411 */     switch (DNum)
/* 356:    */     {
/* 357:    */     case 0: 
/* 358:414 */       s = "Sunday";
/* 359:415 */       break;
/* 360:    */     case 1: 
/* 361:418 */       s = "Monday";
/* 362:    */       
/* 363:420 */       break;
/* 364:    */     case 2: 
/* 365:423 */       s = "Tuesday";
/* 366:    */       
/* 367:425 */       break;
/* 368:    */     case 3: 
/* 369:428 */       s = "Wednesday";
/* 370:    */       
/* 371:430 */       break;
/* 372:    */     case 4: 
/* 373:433 */       s = "Thursday";
/* 374:    */       
/* 375:435 */       break;
/* 376:    */     case 5: 
/* 377:438 */       s = "Friday";
/* 378:    */       
/* 379:440 */       break;
/* 380:    */     case 6: 
/* 381:443 */       s = "Saturday";
/* 382:    */       
/* 383:445 */       break;
/* 384:    */     default: 
/* 385:448 */       s = "DAY IS INCORRECT";
/* 386:    */     }
/* 387:453 */     return s;
/* 388:    */   }
/* 389:    */   
/* 390:    */   public String getMthName(int MNum)
/* 391:    */   {
/* 392:    */     String m;
/* 393:464 */     switch (MNum)
/* 394:    */     {
/* 395:    */     case 0: 
/* 396:467 */       m = " January";
/* 397:    */       
/* 398:469 */       break;
/* 399:    */     case 1: 
/* 400:472 */       m = " February";
/* 401:    */       
/* 402:474 */       break;
/* 403:    */     case 2: 
/* 404:477 */       m = " March";
/* 405:    */       
/* 406:479 */       break;
/* 407:    */     case 3: 
/* 408:482 */       m = " April";
/* 409:    */       
/* 410:484 */       break;
/* 411:    */     case 4: 
/* 412:487 */       m = " May";
/* 413:    */       
/* 414:489 */       break;
/* 415:    */     case 5: 
/* 416:492 */       m = " June";
/* 417:    */       
/* 418:494 */       break;
/* 419:    */     case 6: 
/* 420:497 */       m = " July";
/* 421:    */       
/* 422:499 */       break;
/* 423:    */     case 7: 
/* 424:501 */       m = " August";
/* 425:    */       
/* 426:503 */       break;
/* 427:    */     case 8: 
/* 428:506 */       m = " September";
/* 429:    */       
/* 430:508 */       break;
/* 431:    */     case 9: 
/* 432:511 */       m = " October";
/* 433:    */       
/* 434:513 */       break;
/* 435:    */     case 10: 
/* 436:516 */       m = " November";
/* 437:    */       
/* 438:518 */       break;
/* 439:    */     case 11: 
/* 440:521 */       m = " December";
/* 441:    */       
/* 442:523 */       break;
/* 443:    */     default: 
/* 444:527 */       m = " MONTH IS INCORRECT";
/* 445:    */     }
/* 446:531 */     return m;
/* 447:    */   }
/* 448:    */   
/* 449:    */   public String getPostOutput()
/* 450:    */   {
/* 451:538 */     return this.PostOutput;
/* 452:    */   }
/* 453:    */   
/* 454:    */   public void actionPerformed(ActionEvent evt)
/* 455:    */   {
/* 456:553 */     Object source = evt.getSource();
/* 457:555 */     if (source == this.CLSINGButton) {
/* 458:561 */       this.tframe.dispose();
/* 459:    */     }
/* 460:570 */     if (source == this.PrintButton)
/* 461:    */     {
/* 462:572 */       prtLocFlag = "TrumpDcl";
/* 463:    */       
/* 464:    */ 
/* 465:575 */       PrintUtilities.printComponent(this.tframe, prtLocFlag);
/* 466:    */     }
/* 467:    */   }
/* 468:    */   
/* 469:    */   public void windowClosing(WindowEvent e)
/* 470:    */   {
/* 471:581 */     setVisible(false);
/* 472:    */   }
/* 473:    */   
/* 474:    */   public void windowClosed(WindowEvent e) {}
/* 475:    */   
/* 476:    */   public void windowOpened(WindowEvent e) {}
/* 477:    */   
/* 478:    */   public void windowIconified(WindowEvent e) {}
/* 479:    */   
/* 480:    */   public void windowDeiconified(WindowEvent e) {}
/* 481:    */   
/* 482:    */   public void windowActivated(WindowEvent e) {}
/* 483:    */   
/* 484:    */   public void windowDeactivated(WindowEvent e) {}
/* 485:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     TrumpDcl
 * JD-Core Version:    0.7.1
 */