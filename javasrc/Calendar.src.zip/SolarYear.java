/*   1:    */ public class SolarYear
/*   2:    */   extends Year
/*   3:    */ {
/*   4:    */   public SolarYear(int num)
/*   5:    */   {
/*   6: 11 */     super(num);
/*   7: 12 */     this.nMths = 12;
/*   8: 13 */     this.leap = false;
/*   9: 17 */     if (this.year > 1582) {
/*  10: 19 */       if (((this.year % 4 == 0) && (this.year % 100 != 0)) || (this.year % 400 == 0)) {
/*  11: 20 */         this.leap = true;
/*  12:    */       }
/*  13:    */     }
/*  14: 24 */     if ((this.year > 0) && (this.year < 1583)) {
/*  15: 26 */       if (this.year % 4 == 0) {
/*  16: 27 */         this.leap = true;
/*  17:    */       }
/*  18:    */     }
/*  19: 32 */     if ((this.year < 0) && (this.year % 4 == -1)) {
/*  20: 40 */       this.leap = true;
/*  21:    */     }
/*  22: 44 */     this.months = new Month[12];
/*  23: 45 */     this.months[0] = new Month(0, "January", 31, this);
/*  24: 46 */     if (this.leap) {
/*  25: 47 */       this.months[1] = new Month(1, "February", 29, this);
/*  26:    */     } else {
/*  27: 49 */       this.months[1] = new Month(1, "February", 28, this);
/*  28:    */     }
/*  29: 50 */     this.months[2] = new Month(2, "March", 31, this);
/*  30: 51 */     this.months[3] = new Month(3, "April", 30, this);
/*  31: 52 */     this.months[4] = new Month(4, "May", 31, this);
/*  32: 53 */     this.months[5] = new Month(5, "June", 30, this);
/*  33: 54 */     this.months[6] = new Month(6, "July", 31, this);
/*  34: 55 */     this.months[7] = new Month(7, "August", 31, this);
/*  35: 56 */     this.months[8] = new Month(8, "September", 30, this);
/*  36: 57 */     this.months[9] = new Month(9, "October", 31, this);
/*  37: 58 */     this.months[10] = new Month(10, "November", 30, this);
/*  38: 59 */     this.months[11] = new Month(11, "December", 31, this);
/*  39: 60 */     int i = 0;
/*  40:    */     do
/*  41:    */     {
/*  42: 63 */       this.months[i].setNext(this.months[(i + 1)]);
/*  43: 64 */       this.months[i].getDay(this.months[i].getNDays() - 1).setNext(this.months[(i + 1)].getDay(0));
/*  44: 65 */       i++;
/*  45: 65 */     } while (i < 11);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void connect(Year y)
/*  49:    */   {
/*  50: 76 */     Day dmark = null;
/*  51: 77 */     int day = ((LunarYear)y).getPDay() - 1;
/*  52: 78 */     if (day < 0) {
/*  53: 79 */       day = 6;
/*  54:    */     }
/*  55: 80 */     Day ds = this.months[((LunarYear)y).getPSolMonth()].getDay(((LunarYear)y).getPSolDate() - 1);
/*  56: 81 */     for (Day dl = y.getMonth(6 + (y.isLeap() ? 1 : 0)).getDay(14); dl.getPrev() != null; dl = dl.getPrev())
/*  57:    */     {
/*  58: 83 */       if (ds.getPrev() != null) {
/*  59: 84 */         ds = ds.getPrev();
/*  60: 86 */       } else if (dmark == null) {
/*  61: 87 */         dmark = dl;
/*  62:    */       }
/*  63: 88 */       day--;
/*  64: 88 */       if (day < 0) {
/*  65: 89 */         day = 6;
/*  66:    */       }
/*  67:    */     }
/*  68: 92 */     for (Day dl = y.getMonth(0).getDay(0); dl != null; dl = dl.getNext())
/*  69:    */     {
/*  70: 94 */       if (dl == dmark) {
/*  71: 95 */         dmark = null;
/*  72:    */       }
/*  73: 96 */       day++;
/*  74: 96 */       if (day > 6) {
/*  75: 97 */         day = 0;
/*  76:    */       }
/*  77: 98 */       dl.setDOW(day);
/*  78: 99 */       if ((dmark == null) && (ds != null))
/*  79:    */       {
/*  80:101 */         ds.connect(dl);
/*  81:102 */         ds.setDOW(day);
/*  82:103 */         ds = ds.getNext();
/*  83:    */       }
/*  84:    */     }
/*  85:    */   }
/*  86:    */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     SolarYear
 * JD-Core Version:    0.7.1
 */