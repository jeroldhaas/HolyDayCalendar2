/*  1:   */ import java.io.PrintStream;
/*  2:   */ 
/*  3:   */ public abstract class Year
/*  4:   */ {
/*  5:   */   protected int year;
/*  6:   */   protected Year next;
/*  7:   */   protected Year prev;
/*  8:   */   protected Month[] months;
/*  9:   */   protected boolean leap;
/* 10:   */   protected int nMths;
/* 11:   */   
/* 12:   */   public int getNMths()
/* 13:   */   {
/* 14:10 */     return this.nMths;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setPrev(Year y)
/* 18:   */   {
/* 19:15 */     this.prev = y;
/* 20:16 */     if ((y != null) && (y.next == null)) {
/* 21:17 */       y.next = this;
/* 22:   */     }
/* 23:   */   }
/* 24:   */   
/* 25:   */   public boolean isLeap()
/* 26:   */   {
/* 27:22 */     return this.leap;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Month getMonth(int n)
/* 31:   */   {
/* 32:   */     try
/* 33:   */     {
/* 34:29 */       return this.months[n];
/* 35:   */     }
/* 36:   */     catch (ArrayIndexOutOfBoundsException e)
/* 37:   */     {
/* 38:33 */       System.out.println("Year.getMonth(int) index out of bounds n=" + Integer.toString(n));
/* 39:   */     }
/* 40:35 */     return null;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public Year(int year)
/* 44:   */   {
/* 45:40 */     this.year = year;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public Year(int year, boolean leap) {}
/* 49:   */   
/* 50:   */   public int getYear()
/* 51:   */   {
/* 52:49 */     return this.year;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void setNext(Year y)
/* 56:   */   {
/* 57:54 */     this.next = y;
/* 58:55 */     if ((y != null) && (y.prev == null)) {
/* 59:56 */       y.prev = this;
/* 60:   */     }
/* 61:   */   }
/* 62:   */   
/* 63:   */   public abstract void connect(Year paramYear);
/* 64:   */ }


/* Location:           C:\Users\JHaas\Documents\Projects\jeroldhaas\HolyDayCalendar\javasrc\Calendar.jar
 * Qualified Name:     Year
 * JD-Core Version:    0.7.1
 */